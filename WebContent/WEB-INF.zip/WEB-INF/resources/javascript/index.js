var match_data,session_match;
function processWaitingButtonSpinner(whatToProcess) 
{
	switch (whatToProcess) {
	case 'START_WAIT_TIMER': 
		$('.spinner-border').show();
		$(':button').prop('disabled', true);
		break;
	case 'END_WAIT_TIMER': 
		$('.spinner-border').hide();
		$(':button').prop('disabled', false);
		break;
	}
	
}
function processUserSelectionData(whatToProcess,dataToProcess){
	switch (whatToProcess) {
	case 'LOGGER_FORM_KEYPRESS':
		
		if(session_match.maxOvers > 0){
			if(dataToProcess == 49){
				//alert('You Select Inning 1');	
				document.getElementById('which_keypress').value = 1;
				document.getElementById('selected_inning').innerHTML = 'Selected Inning: 1';
			}
			else if(dataToProcess == 50){
				//alert('You Select Inning 2');	
				document.getElementById('which_keypress').value = 2;
				document.getElementById('selected_inning').innerHTML = 'Selected Inning: 2';
			}
			else{
				alert('This is Limited Overs Match Select Inning 1 or 2')
			}
		}
		else{
			if(dataToProcess == 49){
				//alert('You Select Inning 1');	
				document.getElementById('which_keypress').value = 1;
				document.getElementById('selected_inning').innerHTML = 'Selected Inning: 1';
			}
			else if(dataToProcess == 50){
				//alert('You Select Inning 2');	
				document.getElementById('which_keypress').value = 2;
				document.getElementById('selected_inning').innerHTML = 'Selected Inning: 2';
			}
			else if(dataToProcess == 51){
				//alert('You Select Inning 3');	
				document.getElementById('which_keypress').value = 3;
				document.getElementById('selected_inning').innerHTML = 'Selected Inning: 3';
			}
			else if(dataToProcess == 52){
				//alert('You Select Inning 4');	
				document.getElementById('which_keypress').value = 4;
				document.getElementById('selected_inning').innerHTML = 'Selected Inning: 4';
			}
			else{
				alert('Select Valid inning Number')
			}	
		}
		break;
	}
}
function initialiseForm(whatToProcess,dataToProcess)
{
	session_match = dataToProcess;
	switch (whatToProcess) {
	case 'initialise':
		processUserSelection($('#select_broadcaster'));
		break;
	case 'UPDATE-MATCH-ON-OUTPUT-FORM':
	
	dataToProcess.inning.forEach(function(inn,index,arr){
		inn.battingCard.forEach(function(bc,index,arr){
			if(inn.inningNumber == 1){
				document.getElementById('inning1_number_lbl').innerHTML = 'Current Inning: ' + parseInt(inn.inningNumber);
				document.getElementById('inning1_totalruns_lbl').innerHTML = 'Total Runs: ' + parseInt(inn.totalRuns);
				document.getElementById('inning1_totalovers_lbl').innerHTML = 'Total Overs: ' + parseInt(inn.totalOvers);
				//alert(bc.player.surname);
				if(bc.onStrike == 'YES'){
					document.getElementById('inning1_battingcard1_lbl').innerHTML = 'Batsman-OnStriker: ' + bc.player.surname;
				}
				if(bc.onStrike == 'NO'){
					document.getElementById('inning1_battingcard2_lbl').innerHTML = 'Batsman-NonStriker: ' + bc.player.surname;
				}
				inn.bowlingCard.forEach(function(boc,index,arr){
					document.getElementById('inning1_bowlingcard_lbl').innerHTML = 'Current Bowler:' + boc.player.surname;
				});	
			}
			if(inn.inningNumber == 2){
				document.getElementById('inning2_number_lbl').innerHTML = 'Current Inning: ' + parseInt(inn.inningNumber);
				document.getElementById('inning2_totalruns_lbl').innerHTML = 'Total Runs: ' + parseInt(inn.totalRuns);
				document.getElementById('inning2_totalovers_lbl').innerHTML = 'Total Overs: ' + parseInt(inn.totalOvers);
				if(bc.onStrike == 'YES'){
					document.getElementById('inning2_battingcard1_lbl').innerHTML = 'Batsman-OnStriker: ' + bc.player.surname;
				}
				if(bc.onStrike == 'NO'){
					document.getElementById('inning2_battingcard2_lbl').innerHTML = 'Batsman-NonStriker: ' + bc.player.surname;
				}
				inn.bowlingCard.forEach(function(boc,index,arr){
					document.getElementById('inning2_bowlingcard_lbl').innerHTML = 'Current Bowler:' + boc.player.surname;
				});		
			}
		});
	});
		
		break;
	}
}
function processUserSelection(whichInput)
{	
	switch ($(whichInput).attr('name')) {
		
	case 'selectBottomStat':
		switch ($('#selectBottomStat :selected').val().toUpperCase()) {
		case 'STATISTICS':
			processCricketProcedures('PROMPT_GRAPHICS-OPTIONS')
			break;
		}
		break;
	
	case 'animateout_graphic_btn':
		if(confirm('It will Also Delete Your Preview from Directory...\r\n \r\nAre You Sure To Animate Out? ') == true){
			processCricketProcedures('ANIMATE-OUT');	
		}
		break;
	case 'animate_out_graphic_btn':
		processCricketProcedures('ANIMATE-OUT-RIGHT');	
		break;
	case 'clearall_graphic_btn':
		processCricketProcedures('CLEAR-ALL');
		break;
	case 'animate_out_directors_btn':
		processCricketProcedures('ANIMATE-OUT-DIRECTOR');	
		break;
	case 'animate_out_powerplay_btn':
		processCricketProcedures('ANIMATE-OUT-POWERPLAY');
		break;
	case 'animate_out_bottom_btn':
		processCricketProcedures('ANIMATE-OUT-BOTTOM');
		break;
	case 'bug_graphic_btn': case 'howout_graphic_btn':
	case 'batsmanstats_graphic_btn': case 'bowlerstats_graphic_btn': case 'namesuper_graphic_btn': case 'namesuper_player_graphic_btn': case 'powerplay_graphic_btn':
	case 'infobar_bottom-left_graphic_btn': case 'infobar_graphic_btn': case 'infobar_bottom-right_graphic_btn': case 'playerprofile_graphic_btn': 
	case 'infobar_bottom_graphic_btn':  case 'playingxi_graphic_btn': case 'leaderboard_graphic_btn': case 'ident_graphic_btn': case 'infobar_right_graphic_btn':
	case 'playersummary_graphic_btn': case 'l3playerprofile_graphic_btn': case 'match_promo_graphic_btn': case 'ltmatch_promo_graphic_btn': case 'director_graphic_btn':
	case 'comparision_graphic_btn': case 'bug_dismissal_graphic_btn': case 'split_graphic_btn': case 'bug_db_graphic_btn': case 'infobar_top_graphic_btn': case 'bugbowler_graphic_btn':
	case 'howoutwithoutfielder_graphic_btn': case 'ltbowlerdetails_graphic_btn': case'ltnexttobat_graphic_btn': case'bowlersummary_graphic_btn': case 'landmark_graphic_btn':
	case 'positionlandmark_graphic_btn': case 'batsmanthismatch_graphic_btn': case 'bowlerthismatch_graphic_btn': case 'bowlerstyle_graphic_btn':
	case 'batsmanstyle_graphic_btn': case 'previous_summary_graphic_btn': case 'lt_tieid_double_graphic_btn': case 'generic_lt_graphic_btn': case 'squad_graphic_btn':
		$("#captions_div").hide();
		$("#cancel_match_setup_btn").hide();
		$("#expiry_message").hide();
		
		switch ($(whichInput).attr('name')) {
		
		case 'bug_graphic_btn':
			processCricketProcedures('BUG_GRAPHICS-OPTIONS');
			break;
		case 'bugbowler_graphic_btn':
			processCricketProcedures('BUG_BOWLER_GRAPHICS-OPTIONS');
			break;
		case 'howout_graphic_btn':
			processCricketProcedures('HOWOUT_GRAPHICS-OPTIONS');
			break;
		case 'howoutwithoutfielder_graphic_btn':
			processCricketProcedures('HOWOUT_WITHOUT_FIELDER_GRAPHICS-OPTIONS');
			break;
		case 'batsmanstats_graphic_btn':
			processCricketProcedures('BATSMANSTATS_GRAPHICS-OPTIONS');
			break;
		case 'bowlerstats_graphic_btn':
			processCricketProcedures('BOWLERSTATS_GRAPHICS-OPTIONS');
			break;
		case 'squad_graphic_btn':
			processCricketProcedures('SQUAD_GRAPHICS-OPTIONS');
			break;
		case 'director_graphic_btn':
			addItemsToList('DIRECTOR-OPTIONS',null);
			break;
		case 'powerplay_graphic_btn':
			addItemsToList('POWERPLAY-OPTIONS',null);
			break;
		case 'bug_db_graphic_btn':
			processCricketProcedures('BUG_DB_GRAPHICS-OPTIONS');
			break;
		case 'namesuper_graphic_btn':
			processCricketProcedures('NAMESUPER_GRAPHICS-OPTIONS');
			break;
		case 'namesuper_player_graphic_btn':
			processCricketProcedures('NAMESUPER_PLAYER_GRAPHICS-OPTIONS');
			break;
		case 'landmark_graphic_btn':
			processCricketProcedures('LANDMARK_GRAPHICS-OPTIONS');
			break;
		case 'positionlandmark_graphic_btn':
			processCricketProcedures('POSITION_LANDMARK_GRAPHICS-OPTIONS');
			break;
		case 'playerprofile_graphic_btn':
			processCricketProcedures('PLAYERPROFILE_GRAPHICS-OPTIONS');
			break;
		case 'infobar_top_graphic_btn':
			processCricketProcedures('TOP_GRAPHICS-OPTIONS');
			break;
		case 'infobar_bottom-left_graphic_btn':
			processCricketProcedures('BOTTOMLEFT_GRAPHICS-OPTIONS');
			break;
		case 'infobar_graphic_btn':
			processCricketProcedures('INFOBAR_GRAPHICS-OPTIONS');
			break;
		case 'infobar_bottom-right_graphic_btn':
			processCricketProcedures('BOTTOMRIGHT_GRAPHICS-OPTIONS');
			break;
		case 'infobar_right_graphic_btn':
			processCricketProcedures('RIGHT_GRAPHICS-OPTIONS');
			break;
		case 'ident_graphic_btn':
			processCricketProcedures('IDENT_GRAPHICS-OPTIONS');
			break;
		case 'infobar_bottom_graphic_btn':
			processCricketProcedures('BOTTOM_GRAPHICS-OPTIONS');
			break;
		case 'playingxi_graphic_btn':
			processCricketProcedures('ANIMATE_PLAYINGXI-OPTIONS');
			break;
		case 'leaderboard_graphic_btn':
			addItemsToList('LEADERBOARD-OPTIONS',null);
			break;
		case 'batsmanthismatch_graphic_btn': 
			processCricketProcedures('BATSMAN_THIS_MATCH_GRAPHICS-OPTIONS');
			break;
		case 'bowlerthismatch_graphic_btn': 
			processCricketProcedures('BOWLER_THIS_MATCH_GRAPHICS-OPTIONS');
			break;
		case 'playersummary_graphic_btn': 
			processCricketProcedures('PLAYERSUMMARY_GRAPHICS-OPTIONS');
			break;
		case'bowlersummary_graphic_btn':
			processCricketProcedures('BOWLERSUMMARY_GRAPHICS-OPTIONS');
			break;
		case 'ltbowlerdetails_graphic_btn':
			processCricketProcedures('BOWLERDETAILS_GRAPHICS-OPTIONS');
			break;
		case 'l3playerprofile_graphic_btn':
			processCricketProcedures('L3PLAYERPROFILE_GRAPHICS-OPTIONS');
			break;
		case 'match_promo_graphic_btn':		
			processCricketProcedures('MATCH-PROMO_GRAPHICS-OPTIONS');
			break;
		case 'ltmatch_promo_graphic_btn':
			processCricketProcedures('LTMATCH-PROMO_GRAPHICS-OPTIONS');
			break;
		case 'comparision_graphic_btn':
			processCricketProcedures('COMPARISION-GRAPHICS-OPTIONS');
			break;
		case 'bug_dismissal_graphic_btn':
			processCricketProcedures('BUG_DISMISSAL_GRAPHICS-OPTIONS');
			break;
		case 'split_graphic_btn':
			addItemsToList('SPLIT-OPTIONS',null);
			break;
		case'ltnexttobat_graphic_btn':
			addItemsToList('NEXTTOBAT-OPTIONS',null);
			break;
		case 'bowlerstyle_graphic_btn':
			processCricketProcedures('PLAYERS_GRAPHICS-OPTIONS');
			break;
		case 'batsmanstyle_graphic_btn':
			processCricketProcedures('BATSMAN_STYLE_GRAPHICS-OPTIONS');
			break;
		case 'previous_summary_graphic_btn':
			processCricketProcedures('PREVIOUS_SUMMARY_GRAPHICS-OPTIONS');
			break;
		case 'lt_tieid_double_graphic_btn':
			processCricketProcedures('LT-TIEID-DOUBLE_GRAPHICS-OPTIONS');
			break;
		case 'generic_lt_graphic_btn':
			processCricketProcedures('GENERIC_GRAPHICS-OPTIONS');
			break;
		}
		break;
	case 'scorecard_graphic_btn': case 'bowlingcard_graphic_btn': case 'matchsummary_graphic_btn':  case 'populate_bug_btn': case 'populate_howout_btn': case 'doubleteams_graphic_btn': 
	case 'populate_batsmanstats_btn': case 'populate_bowlerstats_btn': case 'populate_namesuper_btn': case 'populate_namesuper_player_btn': case 'populate_playerprofile_btn':   
	case 'populate_infobar_bottom-left_btn': case 'populate_infobar_btn': case 'populate_infobar_bottom-right_btn': case 'populate_infobar_bottom_btn': case 'target_graphic_btn': 
	case 'populate_playingxi_btn': case 'populate_leaderboard_btn': case 'teamsummary_graphic_btn': case 'populate_playersummary_btn': case 'equation_graphic_btn': case 'populate_squad_btn':
	case 'populate_l3playerprofile_btn': case 'populate_comparision_btn': case 'populate_infobar_prompt_btn':  case 'populate_bug_dismissal_btn': case 'projected_graphic_btn':
	case 'populate_split_btn': case 'populate_bug_db_btn': case 'populate_infobar_top_btn': case 'populate_bug_bowler_btn': case 'ltpartnership_graphic_btn': case 'bugtarget_graphic_btn':
	case 'populate_howout_without_fielder_btn':	case 'populate_bowlerdetails_btn': case'populate_next_to_bat_btn': case 'populate_bowlersummary_btn': case 'ltpowerplay_graphic_btn': case 'ffpartnership_graphic_btn':
	case 'populate_landmark_btn': case 'populate_position_landmark_btn': case 'populate_batsman_this_match_btn': case 'populate_bowler_this_match_btn': case 'pointstable_graphic_btn':
	case 'ltpointstable_graphic_btn': case 'populate_bowlerstyle_btn': case 'populate_batsmanstyle_btn': case 'matchid_graphic_btn': case 'l3matchid_graphic_btn': case 'fallofwicket_graphic_btn':
	case 'manhattan_graphic_btn': case 'populate_match_promo_btn': case 'teams_logo_graphic_btn': case 'populate_previous_summary_btn': case 'populate_lt_tieId_double_btn':
	case 'populate_generic_btn': case 'populate_most_runs_btn': case 'most_runs_graphic_btn': case 'most_wickets_graphic_btn': case 'most_fours_graphic_btn': case 'most_sixes_graphic_btn': case 'highest_runs_graphic_btn':
	case 'populate_ident_btn':	case 'populate_ltmatch_promo_btn': case 'populate_infobar_right_btn': case 'populate_director_btn': case 'quick_howout_graphic_btn': case 'populate_powerplay_btn':
		processWaitingButtonSpinner('START_WAIT_TIMER');
		switch ($(whichInput).attr('name')) {
		case 'scorecard_graphic_btn':
			processCricketProcedures('POPULATE-FF-SCORECARD');
			break;
		case 'quick_howout_graphic_btn':
			processCricketProcedures('POPULATE-L3-QUICK_HOWOUT');
			break;
		case 'bowlingcard_graphic_btn':
			processCricketProcedures('POPULATE-FF-BOWLINGCARD');
			break;
		case 'ltpartnership_graphic_btn':
			processCricketProcedures('POPULATE-LT-PARTNERSHIP');
			break;
		case 'ffpartnership_graphic_btn':
			processCricketProcedures('POPULATE-FF-PARTNERSHIP');
			break;
		case 'ltpowerplay_graphic_btn':
			processCricketProcedures('POPULATE-LT-POWERPLAY');
			break;
		case 'matchsummary_graphic_btn':
			processCricketProcedures('POPULATE-FF-MATCHSUMMARY');
			break;
		case 'teams_logo_graphic_btn':
			processCricketProcedures('POPULATE-FF-TEAMS_LOGO');
			break;
		case 'populate_bug_dismissal_btn':
			processCricketProcedures('POPULATE-L3-BUG-DISMISSAL');
			break;
		case 'populate_howout_btn': 
			processCricketProcedures('POPULATE-L3-HOWOUT');
			break;
		case 'populate_director_btn':
			processCricketProcedures('POPULATE-DIRECTOR');
			break;
		case 'populate_powerplay_btn':
			processCricketProcedures('POPULATE-POWERPLAY');
			break;
		case 'populate_howout_without_fielder_btn':
			processCricketProcedures('POPULATE-L3-HOWOUT_WITHOUT_FIELDER');
			break;
		case 'populate_batsmanstats_btn':
			processCricketProcedures('POPULATE-L3-BATSMANSTATS');
			break;
		case 'populate_bowlerstats_btn':
			processCricketProcedures('POPULATE-L3-BOWLERSTATS');
			break;
		case 'populate_bug_db_btn':
			processCricketProcedures('POPULATE-L3-BUG-DB');
			break;
		case 'populate_namesuper_btn':
			processCricketProcedures('POPULATE-L3-NAMESUPER');
			break;
		case 'populate_namesuper_player_btn':
			processCricketProcedures('POPULATE-L3-NAMESUPER-PLAYER');
			break;
		case 'populate_playerprofile_btn':
			processCricketProcedures('POPULATE-FF-PLAYERPROFILE');
			break;
		case 'doubleteams_graphic_btn':
			processCricketProcedures('POPULATE-FF-DOUBLETEAMS');
			break;
		case 'equation_graphic_btn':
			processCricketProcedures('EQUATION_GRAPHICS-OPTIONS');
			break;
		case 'target_graphic_btn':
			processCricketProcedures('TARGET_GRAPHICS-OPTIONS');
			break;
		case 'populate_infobar_top_btn':
			processCricketProcedures('POPULATE-INFOBAR-TOP');
			break;
		case 'populate_infobar_bottom-left_btn':
			processCricketProcedures('POPULATE-INFOBAR-BOTTOMLEFT');
			break;
		case 'populate_infobar_btn':
			processCricketProcedures('POPULATE-L3-INFOBAR');
			break;
		case 'populate_infobar_bottom-right_btn':
			processCricketProcedures('POPULATE-INFOBAR-BOTTOMRIGHT');
			break;
		case 'populate_infobar_right_btn':
			processCricketProcedures('POPULATE-INFOBAR-RIGHT');
			break;
		case 'populate_ident_btn':
			processCricketProcedures('POPULATE-IDENT');
			break;
		case 'populate_infobar_prompt_btn':
			processCricketProcedures('POPULATE-INFOBAR-PROMPT');
			processCricketProcedures('BOTTOM_GRAPHICS-OPTIONS');
			break;
		case 'populate_infobar_bottom_btn':
			processCricketProcedures('POPULATE-INFOBAR-BOTTOM');
			break;
		case 'populate_generic_btn':
			processCricketProcedures('POPULATE-L3-GENERIC');
			break;
		case 'matchid_graphic_btn':
			processCricketProcedures('POPULATE-FF-MATCHID');
			break;
		case 'l3matchid_graphic_btn':
			processCricketProcedures('POPULATE-LT-MATCHID');
			break;
		case 'projected_graphic_btn':
			processCricketProcedures('PROJECTED_GRAPHICS-OPTIONS');
			break;
		case 'populate_playingxi_btn':
			processCricketProcedures('POPULATE-FF-PLAYINGXI');
			break;
		case 'populate_squad_btn':
			processCricketProcedures('POPULATE-FF-SQUAD');
			break;
		case 'populate_leaderboard_btn':
			processCricketProcedures('POPULATE-FF-LEADERBOARD');
			break;
		case 'bugtarget_graphic_btn':
			processCricketProcedures('POPULATE-L3-BUGTARGET');
			break;
		case 'teamsummary_graphic_btn':
			processCricketProcedures('POPULATE-L3-TEAMSUMMARY');
			break;
		case 'populate_playersummary_btn':
			processCricketProcedures('POPULATE-L3-PLAYERSUMMARY');
			break;
		case 'populate_bowlersummary_btn':
			processCricketProcedures('POPULATE-L3-BOWLERDETAILS');
			break;
		case 'populate_bowlerdetails_btn':
			processCricketProcedures('POPULATE-L3-BOWLERSUMMARY');
			break;
		case 'populate_l3playerprofile_btn':
			processCricketProcedures('POPULATE-L3-PLAYERPROFILE');
			break;
		case 'populate_match_promo_btn':
			processCricketProcedures('POPULATE-MATCH_PROMO');
			break;
		case 'populate_ltmatch_promo_btn':
			processCricketProcedures('POPULATE-LTMATCH_PROMO');
			break;
		case 'fallofwicket_graphic_btn':
			processCricketProcedures('POPULATE-L3-FALLOFWICKET');
			break;
		case 'populate_comparision_btn':
			processCricketProcedures('POPULATE-L3-COMPARISION');
			break;
		case 'populate_bug_btn':
			processCricketProcedures('POPULATE-L3-BUG');
			break;
		case 'populate_bug_bowler_btn':
			processCricketProcedures('POPULATE-L3-BUG-BOWLER');
			break;
		case 'populate_split_btn':
			processCricketProcedures('POPULATE-L3-SPLIT');
			break;
		case 'populate_next_to_bat_btn':
			processCricketProcedures('POPULATE-L3-NEXT_TO_BAT');
			break;
		case 'populate_landmark_btn':
			processCricketProcedures('POPULATE-FF-LANDMARK');
			break;
		case 'populate_position_landmark_btn':
			processCricketProcedures('POPULATE-FF-POSITION_LANDMARK');
			break;
		case 'populate_batsman_this_match_btn':
			processCricketProcedures('POPULATE-L3-BATSMAN_THIS_MATCH');
			break;
		case 'populate_bowler_this_match_btn':
			processCricketProcedures('POPULATE-L3-BOWLER_THIS_MATCH');
			break;
		case 'pointstable_graphic_btn':
			processCricketProcedures('POPULATE-POINTS_TABLE');
			break;
		case 'ltpointstable_graphic_btn':
			processCricketProcedures('POPULATE-LTPOINTS_TABLE');
			break;
		case 'populate_bowlerstyle_btn':
			processCricketProcedures('POPULATE-BOWLER_STYLE');
			break;
		case 'populate_batsmanstyle_btn':
			processCricketProcedures('POPULATE-BATSMAN_STYLE');
			break;
		case 'manhattan_graphic_btn':
			processCricketProcedures('POPULATE-MANHATTAN');
			break;
		case 'populate_previous_summary_btn':
			processCricketProcedures('POPULATE-PREVIOUS_SUMMARY');
			break;
		case 'populate_lt_tieId_double_btn':
			processCricketProcedures('POPULATE-TIEID-DOUBLE');
			break;
		case 'most_runs_graphic_btn':
			processCricketProcedures('POPULATE-MOSTRUNS');
			break;
		case 'most_wickets_graphic_btn':
			processCricketProcedures('POPULATE-MOSTWICKETS');
			break;
		case 'most_fours_graphic_btn':
			processCricketProcedures('POPULATE-MOSTFOURS');
			break;
		case 'most_sixes_graphic_btn':
			processCricketProcedures('POPULATE-MOSTSIXES');
			break;
		case 'highest_runs_graphic_btn':
			processCricketProcedures('POPULATE-HIGHESTSCORE');
			break;
		}
		break;
	case 'cancel_match_setup_btn':
		document.output_form.method = 'post';
		document.output_form.action = 'initialise';
	   	document.output_form.submit();
		break;
	case 'cancel_graphics_btn':
		$('#select_graphic_options_div').empty();
		document.getElementById('select_graphic_options_div').style.display = 'none';
		$("#captions_div").show();
		$("#cancel_match_setup_btn").show();
		break;
	case 'select_broadcaster':
		switch ($('#select_broadcaster :selected').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_VIZ':
			$('#vizPortNumber').attr('value','6100');
			$('label[for=vizScene], input#vizScene').hide();
			$('label[for=which_scene], select#which_scene').show();
			$('label[for=which_layer], select#which_layer').show();
			switch ($('#which_scene :selected').val().toUpperCase()) {
			case 'INFOBAR':
				document.getElementById('selected_which_scene').value = '/Default/ACC/Scorebug';
				break;
			}
			switch ($('#which_layer :selected').val().toUpperCase()) {
			case 'FRONT':
				document.getElementById('selected_which_layer').value = 'FRONT_LAYER';
				break;
			}
			//$('#vizScene').attr('value','/Default/DOAD_In_House/BatBallSummary');
			
			break;
		case 'DOAD_IN_HOUSE_EVEREST':
			$('#vizPortNumber').attr('value','1980');
			$('label[for=vizScene], input#vizScene').hide();
			$('label[for=which_scene], select#which_scene').hide();
			$('label[for=which_layer], select#which_layer').hide();
			break;
		}
		break;
	case 'load_scene_btn':
		if(checkEmpty($('#vizIPAddress'),'IP Address Blank') == false
			|| checkEmpty($('#vizPortNumber'),'Port Number Blank') == false) {
			return false;
		}
      	document.initialise_form.submit();
		break;
	case 'selectInning': case 'selectStatsType':
		switch ($(whichInput).attr('name')) {
		case 'selectInning':
			addItemsToList('POPULATE-PLAYERS',match_data);
			break;
		case 'selectStatsType':
			addItemsToList('POPULATE-PLAYERS',match_data);
			break;
		}
		break;
	case 'selectTeam': case 'selectCaptianWicketKeeper':
		switch ($(whichInput).attr('name')) {
		case 'selectTeam':
			addItemsToList('POPULATE-PLAYER',match_data);
			break;
		case 'selectCaptianWicketKeeper':
			addItemsToList('POPULATE-PLAYER',match_data);
			break;
		}
		break;
	case 'selectTeams':
		switch ($(whichInput).attr('name')) {
		case 'selectTeams':
			addItemsToList('POPULATE-PROFILE',match_data);
			break;
	}
	break;
	case 'selectl3Teams':
		switch ($(whichInput).attr('name')) {
		case 'selectl3Teams':
			addItemsToList('POPULATE-L3PROFILE',match_data);
			break;
	}
	break;
	case 'selectedInning':
		switch ($(whichInput).attr('name')) {
		case 'selectedInning':
			addItemsToList('POPULATE-PLAYERS_DATA',match_data);
			break;
		}
		break;
	case 'selectLandmarkInning': case 'selectedStatsType':
		switch ($(whichInput).attr('name')) {
		case 'selectLandmarkInning':
			addItemsToList('POPULATE-LANDMARK_PLAYERS',match_data);
			break;
		case 'selectedStatsType':
			addItemsToList('POPULATE-LANDMARK_PLAYERS',match_data);
			break;
		}
		break;
	case 'selectPositionLandmarkInning':
		switch ($(whichInput).attr('name')) {
		case 'selectPositionLandmarkInning':
			addItemsToList('POPULATE-POSITION_LANDMARK_PLAYERS',match_data);
			break;
		}
		break;
	case 'selectbowlerthismatchInning':
		switch ($(whichInput).attr('name')) {
		case 'selectbowlerthismatchInning':
			addItemsToList('POPULATE-BOWLER_THIS_MATCH_PLAYERS',match_data);
			break;
		}
		break;
	case 'selectBowlerInning':
		switch ($(whichInput).attr('name')) {
		case 'selectBowlerInning':
			addItemsToList('POPULATE-BOWLERSTYLE',match_data);
			break;
		}
		break;
	case 'selectBugdb':
		switch ($(whichInput).attr('name')) {
		case 'selectBugdb':
			addItemsToList('POPULATE-BUG-SCENE',match_data);
			break;
		}
		break;
	}
}
function processCricketProcedures(whatToProcess)
{
	var valueToProcess;
	switch(whatToProcess) {
	
	case 'READ-MATCH-AND-POPULATE':
		valueToProcess = $('#matchFileTimeStamp').val();
		break;
	case 'POPULATE-FF-SCORECARD': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Bat_Ball_Summ_PTable.sum' + ',' 
								+ document.getElementById('which_keypress').value ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/BatBallSummary' + ',' + document.getElementById('which_keypress').value ;
			break;	
		}
		break;
	case 'POPULATE-FF-BOWLINGCARD': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			//valueToProcess = $('#bowlingScene').val() + ',' + $('#selectInning option:selected').val() ;
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Bat_Ball_Summ_PTable.sum' + ',' 
								+ document.getElementById('which_keypress').value ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			//valueToProcess = $('#bowlingScene').val() + ',' + $('#selectInning option:selected').val() ;
			valueToProcess = '/Default/ACC/BatBallSummary' + ',' + document.getElementById('which_keypress').value ;
			break;	
		}
		break;
	case 'POPULATE-LT-PARTNERSHIP': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Partnership';
			break;	
		}
		break;
	case 'POPULATE-FF-PARTNERSHIP': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#partnershipScene').val() + ',' + document.getElementById('which_keypress').value ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/PartnershipAll';
			break;	
		}
		break;
	case 'POPULATE-LT-POWERPLAY':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Lt_PowerPlay';
			break;	
		}
		break;
	case 'POPULATE-FF-MATCHSUMMARY': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Bat_Ball_Summ_PTable.sum' + ',' 
								+ document.getElementById('which_keypress').value ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/BatBallSummary' + ',' + document.getElementById('which_keypress').value ;
			break;
		}
		break;
	case 'POPULATE-PREVIOUS_SUMMARY':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#previoussummaryScene').val() + ',' + $('#selectTeam1 option:selected').val();
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#previoussummaryScene').val() + ',' + $('#selectTeam1 option:selected').val();
			break;
		}
		break;
	case 'POPULATE-TIEID-DOUBLE':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/MatchIdent_Double' + ',' + $('#selectTieID option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-FF-TEAMS_LOGO':
	switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Teams.sum';
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Teams';
			break;
		}
		break;
	case 'POPULATE-L3-BUG-DISMISSAL':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#bugdismissalScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#bugdismissalScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		}
		break;	
	case 'POPULATE-L3-BUG': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#bugScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#bugScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-BUG-BOWLER':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#bugScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		}
		break;	
	case 'POPULATE-L3-HOWOUT':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#howoutScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#howoutScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-QUICK_HOWOUT':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#howoutScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/LtHowOut' ;
			break;
		}
		break;
	case 'POPULATE-L3-HOWOUT_WITHOUT_FIELDER':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#howoutScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-BATSMANSTATS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#batsmanstatsScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-BOWLERSTATS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#bowlerstatsScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectStatsType option:selected').val() + ',' + $('#selectPlayers option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-BUG-DB':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#bugdbScene').val() + ',' + $('#selectBugdb option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#bugdbScene').val() + ',' + $('#selectBugdb option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-NAMESUPER':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#namesuperScene').val() + ',' + $('#selectNameSuper option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#namesuperScene').val() + ',' + $('#selectNameSuper option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-NAMESUPER-PLAYER':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#namesuperplayerScene').val() + ',' + $('#selectTeam option:selected').val() + ',' + 
				$('#selectCaptainWicketKeeper option:selected').val() + ',' + $('#selectPlayer option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#namesuperplayerScene').val() + ',' + $('#selectTeam option:selected').val() + ',' + 
				$('#selectCaptainWicketKeeper option:selected').val() + ',' + $('#selectPlayer option:selected').val() ;
			break;
		}
		break;
		
	case 'POPULATE-FF-PLAYERPROFILE':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#playerprofileScene').val() + ',' + $('#selectPlayerName option:selected').val()+ ',' + $('#selectProfile option:selected').val() + ',' + $('#selectTypeOfProfile option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#playerprofileScene').val() + ',' + $('#selectPlayerName option:selected').val()+ ',' + $('#selectProfile option:selected').val() + ',' + $('#selectTypeOfProfile option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-INFOBAR-TOP':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectTopStat option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-INFOBAR-BOTTOMLEFT':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#selectBottomLeftStat option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectBottomLeftStat option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-INFOBAR':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#infobarScene').val() + ',' + $('#selectTopLeftStats option:selected').val() + ',' + $('#selectTopRightStats option:selected').val() + ',' + $('#selectBottomLeftStats option:selected').val() + ',' + $('#selectBottomRightStats option:selected').val() ;
			
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#infobarScene').val() + ',' + $('#selectTopLeftStats option:selected').val() + ',' + $('#selectSection4 option:selected').val() + ',' + $('#selectSection5 option:selected').val() ;
			
			break;
		}
		break;
	/*case 'POPULATE-L3-INFOBAR':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#selectTopLeftStats option:selected').val() + ',' + $('#selectTopRightStats option:selected').val() + ',' + $('#selectBottomLeftStats option:selected').val() + ',' + $('#selectBottomRightStats option:selected').val() ;
			
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectTopLeftStats option:selected').val() + ',' + $('#selectSection4 option:selected').val() + ',' + $('#selectSection5 option:selected').val() ;
			
			break;
		}
		break;*/
	case 'POPULATE-INFOBAR-BOTTOMRIGHT':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#selectBottomRightStat option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectBottomRightStat option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-INFOBAR-RIGHT':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#selectRightStat option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectRightStat option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-IDENT':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#infobarScene').val() + ',' + $('#selectIdent option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#infobarScene').val() + ',' + $('#selectIdent option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-DIRECTOR':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectdirector option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-POWERPLAY':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectpowerplay option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-INFOBAR-PROMPT': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectPrompt option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-INFOBAR-BOTTOM':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#selectBottomStat option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#selectBottomStat option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-L3-GENERIC':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#genericScene').val() + ',' + $('#selectStats option:selected').val();
			
			break;
		}
		break;
	case 'POPULATE-FF-MATCHID':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/MatchID.sum';
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/MatchIdent';
			break;
		}
		break;
	case 'POPULATE-LT-MATCHID':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_MATCHID.sum';
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Lt_MatchID';
			break;
		}
		break;
	case 'POPULATE-FF-PLAYINGXI': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#playingxiScene').val() + ',' + $('#selectPlayingXI option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#playingxiScene').val() + ',' + $('#selectPlayingXI option:selected').val() ;
			break;	
		}
		break;
	case 'POPULATE-FF-SQUAD':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Playing_XI_Both.sum';
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#squadScene').val() + ',' + $('#selectSquad option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-FF-LEADERBOARD': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#leaderboardScene').val() + ',' + $('#selectPlayer1').val() + ',' + $('#selectPlayer2').val();
			break;	
		}
		break;
	case 'POPULATE-L3-PROJECTED': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_Projected_Score.sum';
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Lt_ProjectedScore';
			break;	
		}
		break;
	case 'POPULATE-L3-TARGET':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			//valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_Target.sum';
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_NameSuper.sum';
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Lt_Target';
			break;
		}
		break;
	case 'POPULATE-L3-BUGTARGET':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Bug_Target';
			break;	
		}
		break;
	case 'POPULATE-L3-TEAMSUMMARY': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_BattingSummary.sum' + ',' + 
								document.getElementById('which_keypress').value;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Lt_BatingSummary' + ',' + document.getElementById('which_keypress').value;
			break;	
		}
		break;
	case 'POPULATE-L3-PLAYERSUMMARY': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#playersummaryScene').val() + ',' + $('#selectedInning option:selected').val() + ',' + $('#selectPlayerData option:selected').val();
			break;	
		}
		break;
	case 'POPULATE-L3-BOWLERSUMMARY':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#playersummaryScene').val() + ',' + $('#selectedInning option:selected').val() + ',' + $('#selectPlayerData option:selected').val();
			break;	
		}
		break;
	case 'POPULATE-L3-BOWLERDETAILS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#bowlersummaryScene').val() + ',' + $('#selectedInning option:selected').val() + ',' + $('#selectPlayerData option:selected').val();
			break;	
		}
		break;
	case 'POPULATE-L3-PLAYERPROFILE':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#l3playerprofileScene').val() + ',' + $('#selectl3PlayerName option:selected').val()+ ',' + $('#selectl3Profile option:selected').val() + ',' + $('#selectl3TypeOfProfile option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-MATCH_PROMO':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#matchpromoScene').val() + ',' + $('#selectMatchPromo option:selected').val();
			break;
		}
		break;
	case 'POPULATE-LTMATCH_PROMO':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#matchpromoScene').val() + ',' + $('#selectMatchPromo option:selected').val();
			break;
		}
		break;
	case 'POPULATE-L3-FALLOFWICKET':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_FOW.sum' + ',' + 
								document.getElementById('which_keypress').value ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/LtFOW' + ',' + document.getElementById('which_keypress').value ;
			break;
		}
		break;
	case 'POPULATE-L3-SPLIT':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#splitScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectSplitValue option:selected').val() ;
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#splitScene').val() + ',' + $('#selectInning option:selected').val() + ',' + $('#selectSplitValue option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-FF-DOUBLETEAMS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Playing_XI_Both.sum';
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/TeamLineup_Both';
			break;
		}
		break;
	case 'POPULATE-L3-COMPARISION':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = $('#comparisionScene').val();
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#comparisionScene').val();
			break;	
		}
		break;
	case 'POPULATE-L3-NEXT_TO_BAT': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#nexttobatScene').val();
			break;	
		}
		break;
	case 'POPULATE-FF-LANDMARK':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#landmarkScene').val() + ',' + $('#selectLandmarkInning option:selected').val() + ',' + $('#selectedStatsType option:selected').val() + 
								',' + $('#selectlandmarkPlayers option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-FF-POSITION_LANDMARK':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#positionlandmarkScene').val() + ',' + $('#selectPositionLandmarkInning option:selected').val()  + ',' + $('#selectpositionlandmark option:selected').val() ;
			break;
		}
		break;
	case 'POPULATE-LT-EQUATION': 
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': 
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_NameSuper.sum';
			break;
		case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/LtTimeSince';
			break;	
		}
		break;
	case 'POPULATE-L3-BATSMAN_THIS_MATCH':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#batsmanthismatchScene').val() + ',' + $('#selectPositionLandmarkInning option:selected').val()  + ',' + $('#selectpositionlandmark option:selected').val() ;
			break;	
		}
		break;
	case 'POPULATE-L3-BOWLER_THIS_MATCH':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#bowlerthismatchScene').val() + ',' + $('#selectbowlerthismatchInning option:selected').val()  + ',' + $('#selectbowlerthismatch option:selected').val() ;
			break;	
		}
		break;
	case 'POPULATE-POINTS_TABLE':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Points_Table.sum';
			break;	
		case 'DOAD_IN_HOUSE_VIZ':
			//valueToProcess = '/Default/ACC/PointsTable_Mini';/Default/ACC/BatBallSummary
			valueToProcess = '/Default/ACC/BatBallSummary';
			break;	
		}
		break;
	case 'POPULATE-LTPOINTS_TABLE':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/PointsTable_Mini';
			//valueToProcess = '/Default/ACC/BatBallSummary';
			break;	
		}
		break;
	case 'POPULATE-MOSTRUNS': case 'POPULATE-MOSTWICKETS': case 'POPULATE-MOSTFOURS': case 'POPULATE-MOSTSIXES': case 'POPULATE-HIGHESTSCORE':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			//valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/BattingCard.sum';
			valueToProcess = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/FF_Row_Col.sum';
			break;	
		case 'DOAD_IN_HOUSE_VIZ':
			//valueToProcess = '/Default/ACC/PointsTable_Mini';/Default/ACC/BatBallSummary
			valueToProcess = '/Default/ACC/FF_Row_Columm';
			break;	
		}
		break;
	case 'POPULATE-BOWLER_STYLE':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#bowlerstyleScene').val() + ',' + $('#selectBowlerInning option:selected').val() + ',' + $('#selectbowler option:selected').val();
			break;	
		}
		break;
	case 'POPULATE-BATSMAN_STYLE':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = $('#batsmanstyleScene').val() + ',' + $('#selectPositionLandmarkInning option:selected').val() + ',' + $('#selectpositionlandmark option:selected').val();
			break;	
		}
		break;
	case 'POPULATE-MANHATTAN':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
			valueToProcess = '/Default/ACC/Manhattan' + ',' + document.getElementById('which_keypress').value;
			break;	
		}
		break;
	}

	$.ajax({    
        type : 'Get',     
        url : 'processCricketProcedures.html',     
        data : 'whatToProcess=' + whatToProcess + '&valueToProcess=' + valueToProcess, 
        dataType : 'json',
        success : function(data) {
			//match_data = data;
			
        	switch(whatToProcess) {
			case 'READ-MATCH-AND-POPULATE':
				if(data){
					//alert("match = " + $('#matchFileTimeStamp').val() + "Data = "+ data.matchFileTimeStamp)
					if($('#matchFileTimeStamp').val() != data.matchFileTimeStamp) {
						document.getElementById('matchFileTimeStamp').value = data.matchFileTimeStamp;
						initialiseForm("UPDATE-MATCH-ON-OUTPUT-FORM",data);
						//match_data = data;
					}
				}
				break;
			case 'PLAYERS_GRAPHICS-OPTIONS':
				addItemsToList('BOWLERSTYLE-OPTIONS',data);
				addItemsToList('POPULATE-BOWLERSTYLE',data);
				match_data = data;
				break;
			case 'EQUATION_GRAPHICS-OPTIONS':
				addItemsToList('POPULATE-EQUATION',data);
				match_data = data;
				break;
			case 'POSITION_LANDMARK_GRAPHICS-OPTIONS':
				addItemsToList('POSITION_LANDMARK-OPTIONS',data);
				addItemsToList('POPULATE-POSITION_LANDMARK_PLAYERS',data);
				match_data = data;
				break;
			case 'SQUAD_GRAPHICS-OPTIONS':
				addItemsToList('SQUAD-OPTIONS',data);
				match_data = data;
				break;
			case 'LANDMARK_GRAPHICS-OPTIONS':
				addItemsToList('LANDMARK-OPTIONS',data);
				addItemsToList('POPULATE-LANDMARK_PLAYERS',data);
				match_data = data;
				break;
			case 'BUG_DISMISSAL_GRAPHICS-OPTIONS':
				addItemsToList('BUG-DISMISSAL-OPTIONS',data);
				addItemsToList('POPULATE-HOWOUT-PLAYERS',data);
				match_data = data;
				break;
			case 'BUG_GRAPHICS-OPTIONS':
				addItemsToList('BUG-OPTIONS',data);
				addItemsToList('POPULATE-BATSMAN',data);
				match_data = data;
				break;
			case 'BUG_BOWLER_GRAPHICS-OPTIONS':
				addItemsToList('BUG_BOWLER-OPTIONS',data);
				addItemsToList('POPULATE-BOWLER',data);
				match_data = data;
				break;
			case 'HOWOUT_GRAPHICS-OPTIONS':
				addItemsToList('HOWOUT-OPTIONS',data);
				addItemsToList('POPULATE-HOWOUT-PLAYERS',data);
				match_data = data;
				break;
			case 'HOWOUT_WITHOUT_FIELDER_GRAPHICS-OPTIONS':
				addItemsToList('HOWOUT_WITHOUT_FIELDER-OPTIONS',data);
				addItemsToList('POPULATE-HOWOUT-PLAYERS',data);
				match_data = data;
				break;
			case 'BATSMANSTATS_GRAPHICS-OPTIONS':
				addItemsToList('BATSMANSTATS-OPTIONS',data);
				addItemsToList('POPULATE-PLAYERS',data);
				match_data = data;
				break;
			case 'BOWLERSTATS_GRAPHICS-OPTIONS':
				addItemsToList('BOWLERSTATS-OPTIONS',data);
				addItemsToList('POPULATE-PLAYERS',data);
				match_data = data;
				break;
			case 'BATSMAN_STYLE_GRAPHICS-OPTIONS': 
				addItemsToList('BATSMANSTYLE-OPTIONS',data);
				addItemsToList('POPULATE-POSITION_LANDMARK_PLAYERS',data);
				match_data = data;
				break;
			case 'BATSMAN_THIS_MATCH_GRAPHICS-OPTIONS': 
				addItemsToList('BATSMAN_THIS_MATCH-OPTIONS',data);
				addItemsToList('POPULATE-POSITION_LANDMARK_PLAYERS',data);
				match_data = data;
				break;
			case 'BOWLER_THIS_MATCH_GRAPHICS-OPTIONS': 
				addItemsToList('BOWLER_THIS_MATCH-OPTIONS',data);
				addItemsToList('POPULATE-BOWLER_THIS_MATCH_PLAYERS',data);
				match_data = data;
				break;
			case 'PLAYERSUMMARY_GRAPHICS-OPTIONS': 
				addItemsToList('PLAYERSUMMARY-OPTIONS',data);
				addItemsToList('POPULATE-PLAYERS_DATA',data);
				match_data = data;
				break;
			case 'BOWLERSUMMARY_GRAPHICS-OPTIONS':
				addItemsToList('BOWLERSUMMARY-OPTIONS',data);
				addItemsToList('POPULATE-BOWLER_DATA',data);
				match_data = data;
				break;
			case 'BOWLERDETAILS_GRAPHICS-OPTIONS':
				addItemsToList('BOWLERDETAILS-OPTIONS',data);
				addItemsToList('POPULATE-BOWLER_DATA',data);
				match_data = data;
				break;
			case 'BUG_DB_GRAPHICS-OPTIONS':
				addItemsToList('BUG_DB-OPTIONS',data);
				addItemsToList('POPULATE-BUG-SCENE',data);
				match_data = data;
				break;
			case 'NAMESUPER_GRAPHICS-OPTIONS':
				addItemsToList('NAMESUPER-OPTIONS',data);
				match_data = data;
				break;
			case 'NAMESUPER_PLAYER_GRAPHICS-OPTIONS':
				addItemsToList('NAMESUPER_PLAYER-OPTIONS',data);
				addItemsToList('POPULATE-PLAYER',data);
				match_data = data;
				break;
			case 'PLAYERPROFILE_GRAPHICS-OPTIONS':
				addItemsToList('PLAYERPROFILE-OPTIONS',data);
				addItemsToList('POPULATE-PROFILE',data);
				match_data = data;
				break;
			case 'TOP_GRAPHICS-OPTIONS':
				addItemsToList('INFOBAR-TOP-OPTIONS',data);
				match_data = data;
				break;
			case 'BOTTOMLEFT_GRAPHICS-OPTIONS':
				addItemsToList('INFOBAR-BOTTOMLEFT-OPTIONS',data);
				match_data = data;
				break;
			case 'BOTTOMRIGHT_GRAPHICS-OPTIONS':
				addItemsToList('INFOBAR-BOTTOMRIGHT-OPTIONS',data);
				match_data = data;
				break;
			case 'RIGHT_GRAPHICS-OPTIONS':
				addItemsToList('INFOBAR-RIGHT-OPTIONS',data);
				match_data = data;
				break;
			case 'PROMPT_GRAPHICS-OPTIONS':
				addItemsToList('INFOBAR-PROMPT-OPTIONS',data);
				match_data = data;
				break;
			case 'LT-TIEID-DOUBLE_GRAPHICS-OPTIONS':
				addItemsToList('LT-TIEID-DOUBLE-OPTIONS',data);
				match_data = data;
				break;
			case 'INFOBAR_GRAPHICS-OPTIONS':
				addItemsToList('INFOBAR-OPTIONS',data);
				match_data = data;
				break;
			case 'IDENT_GRAPHICS-OPTIONS':
				addItemsToList('IDENT-OPTIONS',data);
				match_data = data;
				break;
			case 'GENERIC_GRAPHICS-OPTIONS': 
				addItemsToList('GENERIC-OPTIONS',data);
				match_data = data;
				break;
			case 'BOTTOM_GRAPHICS-OPTIONS':
				addItemsToList('INFOBAR-BOTTOM-OPTIONS',data);
				match_data = data;
				break;
			case 'ANIMATE_PLAYINGXI-OPTIONS':
				addItemsToList('PLAYINGXI-OPTIONS',data);
				match_data = data;
				break;
			case 'PROJECTED_GRAPHICS-OPTIONS':
				addItemsToList('POPULATE-PROJECTED',data);
				match_data = data;
				break;
			case 'TARGET_GRAPHICS-OPTIONS':
				addItemsToList('POPULATE-TARGET',data);
				match_data = data;
				break;
			case 'L3PLAYERPROFILE_GRAPHICS-OPTIONS':
				addItemsToList('L3PLAYERPROFILE-OPTIONS',data);
				addItemsToList('POPULATE-L3PROFILE',data);
				match_data = data;
				break;
			case 'MATCH-PROMO_GRAPHICS-OPTIONS':
				addItemsToList('MATCH-PROMO-OPTIONS',data);
				match_data = data;
				break;
			case 'LTMATCH-PROMO_GRAPHICS-OPTIONS':
				addItemsToList('LTMATCH-PROMO-OPTIONS',data);
				match_data = data;
				break;
			case 'COMPARISION-GRAPHICS-OPTIONS':
				addItemsToList('POPULATE-COMPARISION',data);
				match_data = data;
				break;
			case 'PREVIOUS_SUMMARY_GRAPHICS-OPTIONS':
				addItemsToList('PREVIOUS_SUMMARY-OPTIONS',data);
				match_data = data;
				break;
			
			case 'POPULATE-FF-MATCHID': case 'POPULATE-LT-MATCHID': case 'POPULATE-FF-LANDMARK': case 'POPULATE-LT-EQUATION': case 'POPULATE-FF-POSITION_LANDMARK':
			case 'POPULATE-L3-BATSMAN_THIS_MATCH': case 'POPULATE-L3-BOWLER_THIS_MATCH': case 'POPULATE-POINTS_TABLE': case 'POPULATE-LTPOINTS_TABLE': case 'POPULATE-BOWLER_STYLE':
			case 'POPULATE-BATSMAN_STYLE': case 'POPULATE-L3-COMPARISION': case 'POPULATE-L3-BUG-DISMISSAL': case 'POPULATE-L3-SPLIT': case 'POPULATE-L3-NAMESUPER': case 'POPULATE-L3-QUICK_HOWOUT':
			case 'POPULATE-L3-NAMESUPER-PLAYER': case 'POPULATE-FF-PLAYERPROFILE': case 'POPULATE-FF-DOUBLETEAMS':  case 'POPULATE-FF-PLAYINGXI':case 'POPULATE-L3-INFOBAR': case 'POPULATE-FF-SQUAD':
			case 'POPULATE-FF-LEADERBOARD':	case 'POPULATE-L3-PROJECTED': case 'POPULATE-L3-TARGET': case 'POPULATE-L3-BUGTARGET': case 'POPULATE-L3-HOWOUT': case 'POPULATE-LT-PARTNERSHIP': 
			case 'POPULATE-L3-HOWOUT_WITHOUT_FIELDER': case 'POPULATE-L3-BATSMANSTATS': case 'POPULATE-L3-BOWLERSTATS':	case 'POPULATE-L3-PLAYERSUMMARY': case 'POPULATE-MATCH_PROMO':
			case 'POPULATE-L3-BOWLERDETAILS': case 'POPULATE-L3-BOWLERSUMMARY': case 'POPULATE-L3-PLAYERPROFILE': case 'POPULATE-L3-BUG': case 'POPULATE-L3-BUG-DB': case 'POPULATE-LTMATCH_PROMO':
			case 'POPULATE-L3-BUG-BOWLER': case 'POPULATE-FF-TEAMS_LOGO': case 'POPULATE-PREVIOUS_SUMMARY': case 'POPULATE-TIEID-DOUBLE': case 'POPULATE-L3-GENERIC': case 'POPULATE-FF-PARTNERSHIP':
			case 'POPULATE-MOSTRUNS': case 'POPULATE-MOSTWICKETS': case 'POPULATE-MOSTFOURS': case 'POPULATE-MOSTSIXES': case 'POPULATE-HIGHESTSCORE': case 'POPULATE-IDENT':
				if (data.status.toUpperCase() == 'SUCCESSFUL') {
					if(confirm('Animate In?') == true){
						$('#select_graphic_options_div').empty();
						document.getElementById('select_graphic_options_div').style.display = 'none';
						$("#captions_div").show();
						
			        	switch(whatToProcess) {
						case 'POPULATE-L3-GENERIC':
							processCricketProcedures('ANIMATE-IN-GENERIC');
							break;
						case 'POPULATE-FF-MATCHID':
							processCricketProcedures('ANIMATE-IN-MATCHID');				
							break;
						case 'POPULATE-LT-MATCHID':
							processCricketProcedures('ANIMATE-IN-L3MATCHID');
							break;
						case 'POPULATE-L3-NEXT_TO_BAT': 
							processCricketProcedures('ANIMATE-IN-NEXT_TO_BAT');
							break;
						case 'POPULATE-FF-LANDMARK':
							processCricketProcedures('ANIMATE-IN-LANDMARK');
							break;
						case 'POPULATE-LT-EQUATION':
							processCricketProcedures('ANIMATE-IN-EQUATION');
							break;
						case 'POPULATE-FF-POSITION_LANDMARK':
							processCricketProcedures('ANIMATE-IN-POSITION_LANDMARK');
							break;
						case 'POPULATE-L3-BATSMAN_THIS_MATCH':
							processCricketProcedures('ANIMATE-IN-BATSMAN_THIS_MATCH');
							break;
						case 'POPULATE-L3-BOWLER_THIS_MATCH':
							processCricketProcedures('ANIMATE-IN-BOWLER_THIS_MATCH');
							break;
						case 'POPULATE-POINTS_TABLE':
							processCricketProcedures('ANIMATE-IN-POINTSTABLE');
							break;
						case 'POPULATE-LTPOINTS_TABLE':
							processCricketProcedures('ANIMATE-IN-LTPOINTSTABLE');
							break;
						case 'POPULATE-MOSTRUNS':
							processCricketProcedures('ANIMATE-IN-MOSTRUNS');
							break;
						case 'POPULATE-MOSTWICKETS':
							processCricketProcedures('ANIMATE-IN-MOSTWICKETS');
							break;
						case 'POPULATE-MOSTFOURS':
							processCricketProcedures('ANIMATE-IN-MOSTFOURS');
							break;
						case 'POPULATE-MOSTSIXES':
							processCricketProcedures('ANIMATE-IN-MOSTSIXES');
							break;
						case 'POPULATE-HIGHESTSCORE':
							processCricketProcedures('ANIMATE-IN-HIGHESTSCORE');
							break;
						case 'POPULATE-BOWLER_STYLE':
							processCricketProcedures('ANIMATE-IN-BOWLER_STYLE');
							break;
						case 'POPULATE-BATSMAN_STYLE':
							processCricketProcedures('ANIMATE-IN-BATSMAN_STYLE');
							break;
						case 'POPULATE-L3-COMPARISION':
							processCricketProcedures('ANIMATE-IN-COMPARISION');				
							break;
						case 'POPULATE-L3-BUG-DISMISSAL':
							processCricketProcedures('ANIMATE-IN-BUG-DISMISSAL');				
							break;
						case 'POPULATE-L3-SPLIT':
							processCricketProcedures('ANIMATE-IN-SPLIT');				
							break;
						case 'POPULATE-L3-NAMESUPER':
							processCricketProcedures('ANIMATE-IN-NAMESUPER');				
							break;
						case 'POPULATE-L3-NAMESUPER-PLAYER':
							processCricketProcedures('ANIMATE-IN-NAMESUPER-PLAYER');
							break;
						case 'POPULATE-FF-PLAYERPROFILE':
							processCricketProcedures('ANIMATE-IN-PLAYERPROFILE');				
							break;
						case 'POPULATE-FF-DOUBLETEAMS':
							processCricketProcedures('ANIMATE-IN-DOUBLETEAMS');				
							break;
						case 'POPULATE-FF-SQUAD':
							processCricketProcedures('ANIMATE-IN-SQUAD');
							break;
						case 'POPULATE-L3-INFOBAR':
							processCricketProcedures('ANIMATE-IN-INFOBAR');				
							break;
						case 'POPULATE-IDENT':
							processCricketProcedures('ANIMATE-IN-IDENT');
							break;
						case 'POPULATE-FF-PLAYINGXI':
							processCricketProcedures('ANIMATE-IN-PLAYINGXI');					
							break;
						case 'POPULATE-FF-LEADERBOARD':
							processCricketProcedures('ANIMATE-IN-LEADERBOARD');					
							break;
						case 'POPULATE-L3-PROJECTED':
							processCricketProcedures('ANIMATE-IN-PROJECTED');					
							break;
						case 'POPULATE-L3-TARGET':
							processCricketProcedures('ANIMATE-IN-TARGET');					
							break;
						case 'POPULATE-L3-BUGTARGET':
							processCricketProcedures('ANIMATE-IN-BUGTARGET');					
							break;
						case 'POPULATE-L3-HOWOUT':
							processCricketProcedures('ANIMATE-IN-HOWOUT');				
							break;
						case 'POPULATE-L3-QUICK_HOWOUT':
							processCricketProcedures('ANIMATE-IN-QUICK_HOWOUT');				
							break;
						case 'POPULATE-L3-HOWOUT_WITHOUT_FIELDER':
							processCricketProcedures('ANIMATE-IN-HOWOUT_WITHOUT_FIELDER');				
							break;
						case 'POPULATE-L3-BATSMANSTATS':
							processCricketProcedures('ANIMATE-IN-BATSMANSTATS');				
							break;
						case 'POPULATE-L3-BOWLERSTATS':
							processCricketProcedures('ANIMATE-IN-BOWLERSTATS');
							break;
						case 'POPULATE-L3-PLAYERSUMMARY': 
							processCricketProcedures('ANIMATE-IN-PLAYERSUMMARY');					
							break;
						case 'POPULATE-L3-BOWLERDETAILS':
							processCricketProcedures('ANIMATE-IN-BOWLERDETAILS');					
							break;
						case 'POPULATE-L3-BOWLERSUMMARY':
							processCricketProcedures('ANIMATE-IN-BOWLERSUMMARY');					
							break;
						case 'POPULATE-L3-PLAYERPROFILE':
							processCricketProcedures('ANIMATE-IN-L3PLAYERPROFILE');				
							break;
						case 'POPULATE-MATCH_PROMO':
							processCricketProcedures('ANIMATE-IN-MATCH_PROMO');				
							break;
						case 'POPULATE-LTMATCH_PROMO':
							processCricketProcedures('ANIMATE-IN-LTMATCH_PROMO');				
							break;
						case 'POPULATE-L3-BUG':
							processCricketProcedures('ANIMATE-IN-BUG');				
							break;
						case 'POPULATE-L3-BUG-DB':
							processCricketProcedures('ANIMATE-IN-BUG-DB');
							break;
						case 'POPULATE-L3-BUG-BOWLER': 
							processCricketProcedures('ANIMATE-IN-BUG-BOWLER');
							break;
						case 'POPULATE-FF-TEAMS_LOGO':
							processCricketProcedures('ANIMATE-IN-TEAMS_LOGO');			
							break;
						case 'POPULATE-PREVIOUS_SUMMARY':
							processCricketProcedures('ANIMATE-IN-PREVIOUS_SUMMARY');
							break;
						case 'POPULATE-TIEID-DOUBLE':
							processCricketProcedures('ANIMATE-IN-TIEID-DOUBLE');
							break;
						case 'POPULATE-FF-PARTNERSHIP':
							processCricketProcedures('ANIMATE-IN-PARTNERSHIP');					
							break;
						case 'POPULATE-LT-PARTNERSHIP':
							processCricketProcedures('ANIMATE-IN-LTPARTNERSHIP');
							break;
						}
					}
				} else {
					alert(data.status);
				}
				break;
			
			case 'POPULATE-FF-SCORECARD': case 'POPULATE-FF-BOWLINGCARD':  case 'POPULATE-FF-MATCHSUMMARY':
			case 'POPULATE-LT-POWERPLAY': case 'POPULATE-MANHATTAN': case 'POPULATE-L3-FALLOFWICKET':
			case 'POPULATE-L3-TEAMSUMMARY': 
			
				if (data.status.toUpperCase() == 'SUCCESSFUL') {
					if(document.getElementById('which_keypress').value == 0){
								alert('You Have Not Selected Inning Cannot Populate Data')
					}
					else{
						if(confirm('Animate In?') == true){
							     
							$('#select_graphic_options_div').empty();
							document.getElementById('select_graphic_options_div').style.display = 'none';
							$("#captions_div").show();
							
				        	switch(whatToProcess) {
							case 'POPULATE-FF-SCORECARD': 
								processCricketProcedures('ANIMATE-IN-SCORECARD');
								break;
							case 'POPULATE-FF-BOWLINGCARD':
								processCricketProcedures('ANIMATE-IN-BOWLINGCARD');					
								break;
							case 'POPULATE-LT-POWERPLAY':
								processCricketProcedures('ANIMATE-IN-LTPOWERPLAY');
								break;
							case 'POPULATE-FF-MATCHSUMMARY':
								processCricketProcedures('ANIMATE-IN-MATCHSUMARRY');			
								break;
							case 'POPULATE-L3-TEAMSUMMARY':
								processCricketProcedures('ANIMATE-IN-TEAMSUMMARY');					
								break;
							case 'POPULATE-L3-FALLOFWICKET':
								processCricketProcedures('ANIMATE-IN-FALLOFWICKET');				
								break;
							case 'POPULATE-MANHATTAN':
								processCricketProcedures('ANIMATE-IN-MANHATTAN');
								break;
							}
						}
					}
				} else {
					alert(data.status);
				}
				break;
        	}
			processWaitingButtonSpinner('END_WAIT_TIMER');
	    },    
	    error : function(e) {    
	  	 	console.log('Error occured in ' + whatToProcess + ' with error description = ' + e);     
	    }    
	});
}
function addItemsToList(whatToProcess, dataToProcess)
{
	var select,option,header_text,div,table,tbody,row,max_cols;
	var cellCount = 0;

	switch (whatToProcess) {
		
	case 'POPULATE-BOWLERSTYLE':
		$('#selectbowler').empty();
		//alert('Hello');
		
		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectBowlerInning option:selected').val()){
					inn.fielders.forEach(function(fldr,fldr_index,bc_arr){
			            $('#selectbowler').append(
							$(document.createElement('option')).prop({
			                value: fldr.playerId,
			                text: fldr.full_name
			            }))					
					});
			}
		});
		break;
		
	case 'POPULATE-LANDMARK_PLAYERS':
		$('#selectlandmarkPlayers').empty();
		//alert('Hello');
		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectLandmarkInning option:selected').val()){
				if($('#selectedStatsType option:selected').val() == 'Batsman'){
					inn.battingCard.forEach(function(bc,bc_index,bc_arr){
			            $('#selectlandmarkPlayers').append(
							$(document.createElement('option')).prop({
			                value: bc.playerId,
			                text: bc.player.full_name
			            }))					
					});
				}
				else{
					inn.bowlingCard.forEach(function(boc,boc_index,bc_arr){
			            $('#selectlandmarkPlayers').append(
							$(document.createElement('option')).prop({
			                value: boc.playerId,
			                text: boc.player.full_name
			            }))					
					});
				} 	
			}
		});
		
		break;	
		
	case 'POPULATE-BATSMAN' :
	
		$('#selectPlayers').empty();

		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectInning option:selected').val()){
				if($('#selectStatsType option:selected').val() == 'Batsman'){
					inn.battingCard.forEach(function(bc,bc_index,bc_arr){
			            $('#selectPlayers').append(
							$(document.createElement('option')).prop({
			                value: bc.playerId,
			                text: bc.player.full_name
			            }))					
					});
				} 	
			}
		});
		break;
	case 'POPULATE-BOWLER' :
	
		$('#selectPlayers').empty();

		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectInning option:selected').val()){
				if($('#selectStatsType option:selected').val() == 'Bowler'){
					inn.bowlingCard.forEach(function(boc,boc_index,boc_arr){
			            $('#selectPlayers').append(
							$(document.createElement('option')).prop({
			                value: boc.playerId,
			                text: boc.player.full_name
			            }))					
					});
				} 
			}
		});
		break;
	case 'POPULATE-PLAYERS' :
	
		$('#selectPlayers').empty();

		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectInning option:selected').val()){
				if($('#selectStatsType option:selected').val() == 'Batsman'){
					inn.battingCard.forEach(function(bc,bc_index,bc_arr){
			            $('#selectPlayers').append(
							$(document.createElement('option')).prop({
			                value: bc.playerId,
			                text: bc.player.full_name
			            }))					
					});
				} else{
					inn.bowlingCard.forEach(function(boc,boc_index,boc_arr){
			            $('#selectPlayers').append(
							$(document.createElement('option')).prop({
			                value: boc.playerId,
			                text: boc.player.full_name
			            }))
			            						
					});
				}	
			}
		});
		break;
	
	case 'POPULATE-HOWOUT-PLAYERS' :
	
		$('#selectPlayers').empty();

		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectInning option:selected').val()){
				if($('#selectStatsType option:selected').val() == 'Batsman'){
					inn.battingCard.forEach(function(bc,bc_index,bc_arr){
						$('#selectPlayers').append(
						$(document.createElement('option')).prop({
		                value: bc.playerId,
		                text: bc.player.full_name + " - " + bc.status
		            	}))				
					});
				}
			}
		});
		break;
		
	case 'POPULATE-PLAYERS_DATA' :
	
		$('#selectPlayerData').empty();
		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectedInning option:selected').val()){
				inn.battingCard.forEach(function(bc,bc_index,bc_arr){
		            $('#selectPlayerData').append(
						$(document.createElement('option')).prop({
		                value: bc.playerId,
		                text: bc.player.full_name
		            }))						
				});
			}
		});
		
		break;
	
	case 'POPULATE-POSITION_LANDMARK_PLAYERS':
		$('#selectpositionlandmark').empty();
		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectPositionLandmarkInning option:selected').val()){
				inn.battingCard.forEach(function(bc,bc_index,bc_arr){
		            $('#selectpositionlandmark').append(
						$(document.createElement('option')).prop({
		                value: bc.playerId,
		                text: bc.player.full_name
		            }))						
				});
			}
		});
		break;
		
	case 'POPULATE-BOWLER_THIS_MATCH_PLAYERS':
		$('#selectbowlerthismatch').empty();
		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectbowlerthismatchInning option:selected').val()){
				inn.bowlingCard.forEach(function(boc,boc_index,bc_arr){
		            $('#selectbowlerthismatch').append(
						$(document.createElement('option')).prop({
		                value: boc.playerId,
		                text: boc.player.full_name
		            }))						
				});
			}
		});
		break;
	
	case 'POPULATE-BOWLER_DATA' :
	
		$('#selectPlayerData').empty();
		dataToProcess.inning.forEach(function(inn,index,arr){
			if(inn.inningNumber == $('#selectedInning option:selected').val()){
				inn.bowlingCard.forEach(function(boc,boc_index,bc_arr){
		            $('#selectPlayerData').append(
						$(document.createElement('option')).prop({
		                value: boc.playerId,
		                text: boc.player.full_name
		            }))						
				});
			}
		});
		
		break;
		
	case 'POPULATE-BUG-SCENE':
		
		$('#bugdbScene').empty();
		
		dataToProcess.forEach(function(bug,index,arr1){
			if(bug.bugId == $('#selectBugdb option:selected').val()){
				
				if(bug.text2 == ''){
					document.getElementById('bugdbScene').value= '/Default/ACC/Bugs';
				}else{
					document.getElementById('bugdbScene').value= '/Default/ACC/Bugs_DoubleLine';
				}
			}
		});
		break;
		
	case 'POPULATE-PROFILE' :

		$('#selectPlayerName').empty();
		
		if(dataToProcess.homeTeamId == $('#selectTeams option:selected').val()){
			dataToProcess.homeSquad.forEach(function(hs,index,arr){
				$('#selectPlayerName').append(
					$(document.createElement('option')).prop({
					value: hs.playerId,
					text: hs.full_name
				}))
			});
			dataToProcess.homeOtherSquad.forEach(function(hos,index,arr){
				$('#selectPlayerName').append(
					$(document.createElement('option')).prop({
					value: hos.playerId,
					text: hos.full_name + ' (OTHER)'
				}))
			});
		}
		else{
			dataToProcess.awaySquad.forEach(function(as,index,arr){
				$('#selectPlayerName').append(
					$(document.createElement('option')).prop({
					value: as.playerId,
					text: as.full_name
				}))
			});
			dataToProcess.awayOtherSquad.forEach(function(aos,index,arr){
				$('#selectPlayerName').append(
					$(document.createElement('option')).prop({
					value: aos.playerId,
					text: aos.full_name + ' (OTHER)'
				}))
			});
		}
		
		break;
	
	case 'POPULATE-L3PROFILE' :

		$('#selectl3PlayerName').empty();
		
		if(dataToProcess.homeTeamId == $('#selectl3Teams option:selected').val()){
			dataToProcess.homeSquad.forEach(function(hs,index,arr){
				$('#selectl3PlayerName').append(
					$(document.createElement('option')).prop({
					value: hs.playerId,
					text: hs.full_name
				}))
			});
			dataToProcess.homeOtherSquad.forEach(function(hos,index,arr){
				$('#selectl3PlayerName').append(
					$(document.createElement('option')).prop({
					value: hos.playerId,
					text: hos.full_name + ' (OTHER)'
				}))
			});
		}
		else{
			dataToProcess.awaySquad.forEach(function(as,index,arr){
				$('#selectl3PlayerName').append(
					$(document.createElement('option')).prop({
					value: as.playerId,
					text: as.full_name
				}))
			});
			dataToProcess.awayOtherSquad.forEach(function(aos,index,arr){
				$('#selectl3PlayerName').append(
					$(document.createElement('option')).prop({
					value: aos.playerId,
					text: aos.full_name + ' (OTHER)'
				}))
			});
		}
		break;
	
	case 'POPULATE-TARGET':
		dataToProcess.inning.forEach(function(t_inn,index,arr1){
			if(t_inn.inningNumber == 1 && t_inn.isCurrentInning == 'YES'){
				if(confirm('TARGET Work Only When Inning is 2 ...\r\n \r\n It may get Affect Your Scene') == true){
					$('#select_graphic_options_div').empty();
					document.getElementById('select_graphic_options_div').style.display = 'none';
					$("#captions_div").show();
				}
				else{
					$('#select_graphic_options_div').empty();
					document.getElementById('select_graphic_options_div').style.display = 'none';
					$("#captions_div").show();
				}
			}
			else if(t_inn.inningNumber == 2 && t_inn.isCurrentInning == 'YES'){
				processCricketProcedures('POPULATE-L3-TARGET');
			}
			});
		break;
		
	case 'POPULATE-EQUATION':
		dataToProcess.inning.forEach(function(t_inn,index,arr1){
			if(t_inn.inningNumber == 1 && t_inn.isCurrentInning == 'YES'){
				if(confirm('EQUATION Work Only When Inning is 2 ...\r\n \r\n It may get Affect Your Scene') == true){
					$('#select_graphic_options_div').empty();
					document.getElementById('select_graphic_options_div').style.display = 'none';
					$("#captions_div").show();
				}
				else{
					$('#select_graphic_options_div').empty();
					document.getElementById('select_graphic_options_div').style.display = 'none';
					$("#captions_div").show();
				}
			}
			else if(t_inn.inningNumber == 2 && t_inn.isCurrentInning == 'YES'){
				processCricketProcedures('POPULATE-LT-EQUATION');
			}
			});
		break;
	
	case 'POPULATE-COMPARISION':
		dataToProcess.inning.forEach(function(inn,index,arr1){
			if(inn.inningNumber == 1 && inn.isCurrentInning == 'YES'){
				if(confirm('COMPARISION Work Only When Inning is 2 ...\r\n \r\n It may get Affect Your Scene') == true){
					$('#select_graphic_options_div').empty();
					document.getElementById('select_graphic_options_div').style.display = 'none';
					$("#captions_div").show();
				}
				else{
					$('#select_graphic_options_div').empty();
					document.getElementById('select_graphic_options_div').style.display = 'none';
					$("#captions_div").show();
				}
			}
			else if(inn.inningNumber == 2 && inn.isCurrentInning == 'YES'){
				addItemsToList('COMPARISION-OPTIONS',null);
			}
			});
		break;
		
	case 'POPULATE-PLAYER':
		$('#selectPlayer').empty();
		if(dataToProcess.homeTeamId ==  $('#selectTeam option:selected').val()){
			dataToProcess.homeSquad.forEach(function(hs,index,arr){
				$('#selectPlayer').append(
					$(document.createElement('option')).prop({
	                value: hs.playerId,
	                text: hs.full_name
		        }))					
			});
		}
		else {
			dataToProcess.awaySquad.forEach(function(as,index,arr){
				$('#selectPlayer').append(
					$(document.createElement('option')).prop({
	                value: as.playerId,
	                text: as.full_name
		        }))					
			});
		}
		
		break;
		
	case 'POPULATE-PROJECTED':
		dataToProcess.inning.forEach(function(inn,index,arr2){
			if(inn.inningNumber == 2 && inn.isCurrentInning == 'YES'){
				if(confirm('Projected Score Work Only When Inning is 1 ...\r\n \r\n It may get Affect Your Scene') == true){
					$('#select_graphic_options_div').empty();
					document.getElementById('select_graphic_options_div').style.display = 'none';
					$("#captions_div").show();
				}
				else{
					$('#select_graphic_options_div').empty();
					document.getElementById('select_graphic_options_div').style.display = 'none';
					$("#captions_div").show();
				}
				//alert('Projected Score Work Only When Inning is 1 ...');
			}
			else{
				processCricketProcedures('POPULATE-L3-PROJECTED');
			}
		});
		break;
	
 	
	case'BUG-DISMISSAL-OPTIONS': case'HOWOUT-OPTIONS': case'HOWOUT_WITHOUT_FIELDER-OPTIONS': case 'SPLIT-OPTIONS': case'BUG_BOWLER-OPTIONS':
	case'BATSMANSTATS-OPTIONS': case 'BOWLERSTATS-OPTIONS': case'BUG-OPTIONS': case 'TEAMS_LOGO-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			case'BUG-DISMISSAL-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select.setAttribute('onchange',"processUserSelection(this)");

						select = document.createElement('select');
						select.id = 'selectStatsType';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Batsman';
						option.text = 'Batsman';
						select.appendChild(option);
						
					    select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectPlayers';
						select.name = select.id;
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						switch ($('#selected_broadcaster').val().toUpperCase()) {
							case 'DOAD_IN_HOUSE_EVEREST': 
								select = document.createElement('input');
								select.type = "text";
								select.id = 'bugdismissalScene';
								select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Bug_SingleLine.sum';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
							case 'DOAD_IN_HOUSE_VIZ':
								select = document.createElement('input');
								select.type = "text";
								select.id = 'bugdismissalScene';
								select.value = '/Default/ACC/Bugs_DoubleLine';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
						}
						break;	
					}
					break;
			
			case'BUG-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select.setAttribute('onchange',"processUserSelection(this)");

						select = document.createElement('select');
						select.id = 'selectStatsType';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Batsman';
						option.text = 'Batsman';
						select.appendChild(option);
						
					    select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectPlayers';
						select.name = select.id;
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						switch ($('#selected_broadcaster').val().toUpperCase()) {
							case 'DOAD_IN_HOUSE_EVEREST': 
								select = document.createElement('input');
								select.type = "text";
								select.id = 'bugScene';
								select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Bug_SingleLine.sum';

								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
							case 'DOAD_IN_HOUSE_VIZ':
								select = document.createElement('input');
								select.type = "text";
								select.id = 'bugScene';
								select.value = '/Default/ACC/Bugs_DoubleLine';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
						}
						break;	
					}
					break;
			case'BUG_BOWLER-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select.setAttribute('onchange',"processUserSelection(this)");

						select = document.createElement('select');
						select.id = 'selectStatsType';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Bowler';
						option.text = 'Bowler';
						select.appendChild(option);
						
					    select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectPlayers';
						select.name = select.id;
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						switch ($('#selected_broadcaster').val().toUpperCase()) {
							case 'DOAD_IN_HOUSE_EVEREST': 
								select = document.createElement('input');
								select.type = "text";
								select.id = 'bugScene';
								select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Bug_SingleLine.sum';

								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
							case 'DOAD_IN_HOUSE_VIZ':
								select = document.createElement('input');
								select.type = "text";
								select.id = 'bugScene';
								select.value = '/Default/ACC/Bugs';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
						}
						break;	
					}
					break;	

			case'HOWOUT-OPTIONS': 
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select.setAttribute('onchange',"processUserSelection(this)");

						select = document.createElement('select');
						select.id = 'selectStatsType';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Batsman';
						option.text = 'Batsman';
						select.appendChild(option);
						
					    select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectPlayers';
						select.name = select.id;
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						switch ($('#selected_broadcaster').val().toUpperCase()) {
							case 'DOAD_IN_HOUSE_EVEREST': 
								select = document.createElement('input');
								select.type = "text";
								select.id = 'howoutScene';
								select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_Batsman_Out.sum';

								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
							case 'DOAD_IN_HOUSE_VIZ':
								select = document.createElement('input');
								select.type = "text";
								select.id = 'howoutScene';
								select.value = '/Default/ACC/LtHowOut';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
						}
						break;	
					}
					break;
			
			case'HOWOUT_WITHOUT_FIELDER-OPTIONS': 
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select.setAttribute('onchange',"processUserSelection(this)");

						select = document.createElement('select');
						select.id = 'selectStatsType';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Batsman';
						option.text = 'Batsman';
						select.appendChild(option);
						
					    select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectPlayers';
						select.name = select.id;
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						switch ($('#selected_broadcaster').val().toUpperCase()) {
							case 'DOAD_IN_HOUSE_EVEREST': 
								select = document.createElement('input');
								select.type = "text";
								select.id = 'howoutScene';
								select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_Batsman_Out.sum';

								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
							case 'DOAD_IN_HOUSE_VIZ':
								select = document.createElement('input');
								select.type = "text";
								select.id = 'howoutScene';
								select.value = '/Default/ACC/LtHowOut';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
						}
						break;	
					}
					break;
				
			case'BATSMANSTATS-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
		
			case 'DOAD_IN_HOUSE_EVEREST': 
				select.setAttribute('onchange',"processUserSelection(this)");

				select = document.createElement('select');
				select.id = 'selectStatsType';
				select.name = select.id;
				
				option = document.createElement('option');
				option.value = 'Batsman';
				option.text = 'Batsman';
				select.appendChild(option);
				
			    select.setAttribute('onchange',"processUserSelection(this)");
				row.insertCell(cellCount).appendChild(select);
				
				cellCount = cellCount + 1;
				
				select = document.createElement('select');
				select.id = 'selectPlayers';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);

				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'batsmanstatsScene';
				select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_Batsman_Score.sum';
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");

				select = document.createElement('select');
				select.id = 'selectStatsType';
				select.name = select.id;
				
				option = document.createElement('option');
				option.value = 'Batsman';
				option.text = 'Batsman';
				select.appendChild(option);
				
			    select.setAttribute('onchange',"processUserSelection(this)");
				row.insertCell(cellCount).appendChild(select);
				
				cellCount = cellCount + 1;
				
				select = document.createElement('select');
				select.id = 'selectPlayers';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);

				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'batsmanstatsScene';
				select.value = '/Default/ACC/LtPlayerStats';
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				break;
			}
				break;
			case 'BOWLERSTATS-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
		
			case 'DOAD_IN_HOUSE_EVEREST':
				select.setAttribute('onchange',"processUserSelection(this)");

				select = document.createElement('select');
				select.id = 'selectStatsType';
				select.name = select.id;
				
				option = document.createElement('option');
				option.value = 'Bowler';
				option.text = 'Bowler';
				select.appendChild(option);
				
			    select.setAttribute('onchange',"processUserSelection(this)");
				row.insertCell(cellCount).appendChild(select);
				
				cellCount = cellCount + 1;
				
				select = document.createElement('select');
				select.id = 'selectPlayers';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);

				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'bowlerstatsScene';
				select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_BowlerStat.sum';
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				break;
				
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");

				select = document.createElement('select');
				select.id = 'selectStatsType';
				select.name = select.id;
				
				option = document.createElement('option');
				option.value = 'Bowler';
				option.text = 'Bowler';
				select.appendChild(option);
				
			    select.setAttribute('onchange',"processUserSelection(this)");
				row.insertCell(cellCount).appendChild(select);
				
				cellCount = cellCount + 1;
				
				select = document.createElement('select');
				select.id = 'selectPlayers';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);

				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'bowlerstatsScene';
				select.value = '/Default/ACC/Lt_BowlerBowlingDetails';
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1; 
				break;
			
			}
			
			break;
			
			case 'SPLIT-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
				case 'DOAD_IN_HOUSE_EVEREST':
					select = document.createElement('select');
					select.id = 'selectSplitValue';
					select.name = select.id;
					
					option = document.createElement('option');
					option.value = '30';
					option.text = '30 Split';
					select.appendChild(option);
					
					option = document.createElement('option');
					option.value = '50';
					option.text = '50 Split';
					select.appendChild(option);
					
				    select.setAttribute('onchange',"processUserSelection(this)");
					row.insertCell(cellCount).appendChild(select);
					
					cellCount = cellCount + 1;
				
					select = document.createElement('input');
					select.type = "text";
					select.id = 'splitScene';
					select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_30-50Split.sum';
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
					break;
					
				case 'DOAD_IN_HOUSE_VIZ':
					select = document.createElement('select');
					select.id = 'selectSplitValue';
					select.name = select.id;
					
					option = document.createElement('option');
					option.value = '30';
					option.text = '30 Split';
					select.appendChild(option);
					
					option = document.createElement('option');
					option.value = '50';
					option.text = '50 Split';
					select.appendChild(option);
					
				    select.setAttribute('onchange',"processUserSelection(this)");
					row.insertCell(cellCount).appendChild(select);
					
					cellCount = cellCount + 1;
				
					select = document.createElement('input');
					select.type = "text";
					select.id = 'splitScene';
					select.value = '/Default/ACC/Lt_30_50_Splits';
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
					break;
			}
				break;
		}
		
		option = document.createElement('input');
	    option.type = 'button';
		    
			switch (whatToProcess) {
			
			case'BUG-DISMISSAL-OPTIONS':
			    option.name = 'populate_bug_dismissal_btn';
			    option.value = 'Populate Bug-Dismissal';
				break;
			case'BUG-OPTIONS':
			    option.name = 'populate_bug_btn';
			    option.value = 'Populate Bug';
				break;
			case'BUG_BOWLER-OPTIONS':
			    option.name = 'populate_bug_bowler_btn';
			    option.value = 'Populate BugBowler Figure';
				break;
			case'HOWOUT-OPTIONS':
			    option.name = 'populate_howout_btn';
			    option.value = 'Populate Howout';
				break;
			case'HOWOUT_WITHOUT_FIELDER-OPTIONS':
			    option.name = 'populate_howout_without_fielder_btn';
			    option.value = 'Populate Howout';
				break;
			case'BATSMANSTATS-OPTIONS':
			    option.name = 'populate_batsmanstats_btn';
			    option.value = 'Populate Batsmanstats';
				break;
			case 'BOWLERSTATS-OPTIONS':
				option.name = 'populate_bowlerstats_btn';
			    option.value = 'Populate Bowlerstats';
				break;
			case 'SPLIT-OPTIONS':
				option.name = 'populate_split_btn';
			    option.value = 'Populate 30-50 Split';
				break;
			}
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
	
	case 'MATCH-PROMO-OPTIONS': case 'DIRECTOR-OPTIONS': case 'POWERPLAY-OPTIONS':
	switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			switch(whatToProcess){
				case 'POWERPLAY-OPTIONS':
					switch ($('#selected_broadcaster').val().toUpperCase()){
						case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('select');
						select.id = 'selectpowerplay';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'powerplay';
						option.text = 'PowerPlay' ;
						select.appendChild(option);
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						break;
					}
					break;
				case 'DIRECTOR-OPTIONS':
					switch ($('#selected_broadcaster').val().toUpperCase()){
						case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('select');
						select.id = 'selectdirector';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'FOURS';
						option.text = 'FOURS' ;
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'SIXES';
						option.text = 'SIXES' ;
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'WICKETS';
						option.text = 'WICKETS' ;
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'WIDE';
						option.text = 'WIDE' ;
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'NO_BALL';
						option.text = 'NO_BALL' ;
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'FREE-HIT';
						option.text = 'FREE-HIT' ;
						select.appendChild(option);
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						break;
					}
					break;
				case 'MATCH-PROMO-OPTIONS':
					switch ($('#selected_broadcaster').val().toUpperCase()){
						case 'DOAD_IN_HOUSE_EVEREST':
						select = document.createElement('input');
						select.type = "text";
						select.id = 'matchpromoScene';
						select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Match_ID.sum';
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectMatchPromo';
						select.name = select.id;
						
						dataToProcess.forEach(function(oop,index,arr1){	
							option = document.createElement('option');
		                    option.value = oop.matchnumber;
		                    option.text = oop.matchnumber + ' - ' +oop.home_Team.fullname + ' Vs ' + oop.away_Team.fullname ;
		                    select.appendChild(option);
								
		                });
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						break;
					case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('input');
						select.type = "text";
						select.id = 'matchpromoScene';
						select.value = '/Default/ACC/MatchIdent';
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectMatchPromo';
						select.name = select.id;
						
						dataToProcess.forEach(function(oop,index,arr1){	
							option = document.createElement('option');
		                    option.value = oop.matchnumber;
		                    option.text = oop.matchnumber + ' - ' +oop.home_Team.fullname + ' Vs ' + oop.away_Team.fullname ;
		                    select.appendChild(option);
								
		                });
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						break;
					}
				break;
			}
			option = document.createElement('input');
		    option.type = 'button';
			switch(whatToProcess){
				case 'POWERPLAY-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
				case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
					option.name = 'populate_powerplay_btn';
					option.value = 'Populate PowerPlay';
				    option.id = option.name;
				    
				    option.setAttribute('onclick',"processUserSelection(this)");
				    
				    div = document.createElement('div');
				    div.append(option);
		    
		    		option = document.createElement('input');
					option.type = 'button';
					option.name = 'animate_out_powerplay_btn';
					option.id = option.name;
					option.value = 'Animate out ';
					option.setAttribute('onclick','processUserSelection(this)');
			
				    div.append(option);
				    
				    row.insertCell(cellCount).appendChild(div);
				    cellCount = cellCount + 1;
			    
					option = document.createElement('input');
					option.type = 'button';
					option.name = 'cancel_graphics_btn';
					option.id = option.name;
					option.value = 'Cancel';
					option.setAttribute('onclick','processUserSelection(this)');
			
				    div.append(option);
				    
				    row.insertCell(cellCount).appendChild(div);
				    cellCount = cellCount + 1;
				    
					document.getElementById('select_graphic_options_div').style.display = '';
					break;
				}
					break;
				case 'DIRECTOR-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
				case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
					option.name = 'populate_director_btn';
					option.value = 'Populate Director';
				    option.id = option.name;
				    
				    option.setAttribute('onclick',"processUserSelection(this)");
				    
				    div = document.createElement('div');
				    div.append(option);
		    
		    		option = document.createElement('input');
					option.type = 'button';
					option.name = 'animate_out_directors_btn';
					option.id = option.name;
					option.value = 'Animate out ';
					option.setAttribute('onclick','processUserSelection(this)');
			
				    div.append(option);
				    
				    row.insertCell(cellCount).appendChild(div);
				    cellCount = cellCount + 1;
			    
					option = document.createElement('input');
					option.type = 'button';
					option.name = 'cancel_graphics_btn';
					option.id = option.name;
					option.value = 'Cancel';
					option.setAttribute('onclick','processUserSelection(this)');
			
				    div.append(option);
				    
				    row.insertCell(cellCount).appendChild(div);
				    cellCount = cellCount + 1;
				    
					document.getElementById('select_graphic_options_div').style.display = '';
					break;
				}
					break;
				case 'MATCH-PROMO-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
				case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
					option.name = 'populate_match_promo_btn';
					option.value = 'Populate Match Promo';
				    option.id = option.name;
				    
				    option.setAttribute('onclick',"processUserSelection(this)");
				    
				    div = document.createElement('div');
				    div.append(option);
					
					option = document.createElement('input');
					option.type = 'button';
					option.name = 'cancel_graphics_btn';
					option.id = option.name;
					option.value = 'Cancel';
					option.setAttribute('onclick','processUserSelection(this)');
			
				    div.append(option);
				    
				    row.insertCell(cellCount).appendChild(div);
				    cellCount = cellCount + 1;
				    
					document.getElementById('select_graphic_options_div').style.display = '';
					break;
				}
					break;
					
				}	
			}
		break;
		
	case 'LTMATCH-PROMO-OPTIONS':
	switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			switch(whatToProcess){
				case 'LTMATCH-PROMO-OPTIONS':
					switch ($('#selected_broadcaster').val().toUpperCase()){
						case 'DOAD_IN_HOUSE_EVEREST':
						select = document.createElement('input');
						select.type = "text";
						select.id = 'matchpromoScene';
						select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Match_ID.sum';
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectMatchPromo';
						select.name = select.id;
						
						dataToProcess.forEach(function(oop,index,arr1){	
							option = document.createElement('option');
		                    option.value = oop.matchnumber;
		                    option.text = oop.matchnumber + ' - ' +oop.home_Team.fullname + ' Vs ' + oop.away_Team.fullname ;
		                    select.appendChild(option);
								
		                });
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						break;
					case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('input');
						select.type = "text";
						select.id = 'matchpromoScene';
						select.value = '/Default/ACC/Lt_MatchID';
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectMatchPromo';
						select.name = select.id;
						
						dataToProcess.forEach(function(oop,index,arr2){	
							option = document.createElement('option');
		                    option.value = oop.matchnumber;
		                    option.text = oop.matchnumber + ' - ' +oop.home_Team.fullname + ' Vs ' + oop.away_Team.fullname ;
		                    select.appendChild(option);
								
		                });
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						break;
					}
				break;
			}
			option = document.createElement('input');
		    option.type = 'button';
			switch(whatToProcess){
				
				case 'LTMATCH-PROMO-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
				case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
					option.name = 'populate_ltmatch_promo_btn';
					option.value = 'Populate Match Promo';
				    option.id = option.name;
				    
				    option.setAttribute('onclick',"processUserSelection(this)");
				    
				    div = document.createElement('div');
				    div.append(option);
					
					option = document.createElement('input');
					option.type = 'button';
					option.name = 'cancel_graphics_btn';
					option.id = option.name;
					option.value = 'Cancel';
					option.setAttribute('onclick','processUserSelection(this)');
			
				    div.append(option);
				    
				    row.insertCell(cellCount).appendChild(div);
				    cellCount = cellCount + 1;
				    
					document.getElementById('select_graphic_options_div').style.display = '';
					break;
				}
					break;
					
				}	
			}
		break;
		
		
	case'NAMESUPER-OPTIONS': case 'NAMESUPER_PLAYER-OPTIONS':  case'PLAYERPROFILE-OPTIONS': case'L3PLAYERPROFILE-OPTIONS': case 'BUG_DB-OPTIONS': case 'PREVIOUS_SUMMARY-OPTIONS':
	case 'LT-TIEID-DOUBLE-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			switch(whatToProcess){
			case 'LT-TIEID-DOUBLE-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
				case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
					select = document.createElement('select');
					select.id = 'selectTieID';
					select.name = select.id;
					
					
					option = document.createElement('option');
					option.value = 'today';
					option.text = 'Today' ;
					select.appendChild(option);
					
					option = document.createElement('option');
					option.value = 'tomorrow';
					option.text = 'Tomorrow' ;
					select.appendChild(option);
					
					
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
				
					
					break;
				}
				
				break;
				
				case 'PREVIOUS_SUMMARY-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
				case 'DOAD_IN_HOUSE_EVEREST':
					select = document.createElement('input');
					select.type = "text";
					select.id = 'previoussummaryScene';
					select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Summary.sum';
					
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
					
					select = document.createElement('select');
					select.id = 'selectTeam1';
					select.name = select.id;
					
					dataToProcess.forEach(function(oop,index,arr1){
							
						option = document.createElement('option');
	                    option.value = oop.matchnumber;
	                    option.text = 'Match ' + oop.matchnumber +"- "+ oop.home_Team.fullname + ' Vs ' + oop.away_Team.fullname;
	                    select.appendChild(option);
							
	                });
					
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
					break;
				case 'DOAD_IN_HOUSE_VIZ':
					select = document.createElement('input');
					select.type = "text";
					select.id = 'previoussummaryScene';
					select.value = '/Default/ACC/BatBallSummary';
					
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
					
					select = document.createElement('select');
					select.id = 'selectTeam1';
					select.name = select.id;
					
					dataToProcess.forEach(function(oop,index,arr1){
							
						option = document.createElement('option');
	                    option.value = oop.matchnumber;
	                    option.text = 'Match ' + oop.matchnumber +"- "+ oop.home_Team.fullname + ' Vs ' + oop.away_Team.fullname;
	                    select.appendChild(option);
							
	                });
					
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
					break;
				}
				break;
				
				case'NAMESUPER-OPTIONS':
					switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('select');
						select.style = 'width:130px';
						select.id = 'selectNameSuper';
						select.name = select.id;
						
						dataToProcess.forEach(function(ns,index,arr1){
							option = document.createElement('option');
							option.value = ns.namesuperId;
							option.text = ns.subHeader ;
							select.appendChild(option);
						});
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						switch ($('#selected_broadcaster').val().toUpperCase()) {
						case 'DOAD_IN_HOUSE_EVEREST': 
							select = document.createElement('input');
							select.type = "text";
							select.id = 'namesuperScene';
							select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_NameSuper.sum';
							
							row.insertCell(cellCount).appendChild(select);
							cellCount = cellCount + 1;
							
							break;
							
						case 'DOAD_IN_HOUSE_VIZ':
							select = document.createElement('input');
							select.type = "text";
							select.id = 'namesuperScene';
							select.value = '/Default/ACC/LtNameSuper';
							
							row.insertCell(cellCount).appendChild(select);
							cellCount = cellCount + 1;
							break;
						}
						break;
					}
					break;
				
			case 'NAMESUPER_PLAYER-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('select');
						select.id = 'selectTeam';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = dataToProcess.homeTeamId;
						option.text = dataToProcess.homeTeam.shortname;
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = dataToProcess.awayTeamId;
						option.text = dataToProcess.awayTeam.shortname;
						select.appendChild(option);
					
						select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
		
						select = document.createElement('select');
						select.style = 'width:100px';
						select.id = 'selectCaptainWicketKeeper';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Captain';
						option.text = 'Captain';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'Captain-WicketKeeper';
						option.text = 'Captain-WicketKeeper';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'Player';
						option.text = 'Player';
						select.appendChild(option);
		
						option = document.createElement('option');
						option.value = 'Player Of The Match';
						option.text = 'Player Of The Match';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'Wicket_Keeper';
						option.text = 'WicketKeeper';
						select.appendChild(option);
						
						select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.style = 'width:100px';
						select.id = 'selectPlayer';
						select.name = select.id;
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						switch ($('#selected_broadcaster').val().toUpperCase()) {
							case 'DOAD_IN_HOUSE_EVEREST': 
								select = document.createElement('input');
								select.type = "text";
								select.id = 'namesuperplayerScene';
								select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_NameSuper.sum';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
							
							case 'DOAD_IN_HOUSE_VIZ':
								select = document.createElement('input');
								select.type = "text";
								select.id = 'namesuperplayerScene';
								select.value = '/Default/ACC/LtNameSuper';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
								break;
						}
						break;
				}
				break;
					
			case'PLAYERPROFILE-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('select');
						select.id = 'selectTeams';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = dataToProcess.homeTeamId;
						option.text = dataToProcess.homeTeam.shortname;
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = dataToProcess.awayTeamId;
						option.text = dataToProcess.awayTeam.shortname;
						select.appendChild(option);
						
						select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectPlayerName';
						select.name = select.id;
						
						select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectProfile';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'IT20';
						option.text = 'T20I';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'DT20';
						option.text = 'DT20';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'ODI';
						option.text = 'ODI';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'Test';
						option.text = 'Test';
						select.appendChild(option);
						
						select.setAttribute('onchange',"processUserSelection(this)");
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectTypeOfProfile';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Batsman';
						option.text = 'Batsman';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'Bowler';
						option.text = 'Bowler';
						select.appendChild(option);
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						switch(whatToProcess){
							case'PLAYERPROFILE-OPTIONS':
							switch ($('#selected_broadcaster').val().toUpperCase()) {
							case 'DOAD_IN_HOUSE_EVEREST':
								select = document.createElement('input');
								select.type = "text";
								select.id = 'playerprofileScene';
								select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/Mumbai_Indians/Everes_Scenes/Scenes/MI_PlayerProfile.sum';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								break;
							case 'DOAD_IN_HOUSE_VIZ':
								select = document.createElement('input');
								select.type = "text";
								select.id = 'playerprofileScene';
								select.value = '/Default/ACC/PlayerProfile';
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								break;
						}
							break;
							}
						
						break;
				} 
				break;
				
			case'L3PLAYERPROFILE-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('select');
						select.id = 'selectl3Teams';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = dataToProcess.homeTeamId;
						option.text = dataToProcess.homeTeam.shortname;
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = dataToProcess.awayTeamId;
						option.text = dataToProcess.awayTeam.shortname;
						select.appendChild(option);
						
						select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectl3PlayerName';
						select.name = select.id;
						
						select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectl3Profile';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'IT20';
						option.text = 'T20I';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'DT20';
						option.text = 'DT20';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'ODI';
						option.text = 'ODI';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'Test';
						option.text = 'Test';
						select.appendChild(option);
						
						select.setAttribute('onchange',"processUserSelection(this)");
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectl3TypeOfProfile';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Batsman';
						option.text = 'Batsman';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'Bowler';
						option.text = 'Bowler';
						select.appendChild(option);
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						switch(whatToProcess){
							case'L3PLAYERPROFILE-OPTIONS':
							switch ($('#selected_broadcaster').val().toUpperCase()) {
								case 'DOAD_IN_HOUSE_EVEREST':
									select = document.createElement('input');
									select.type = "text";
									select.id = 'l3playerprofileScene';
									select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_PlayerProfile.sum';
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
									break;
								case 'DOAD_IN_HOUSE_VIZ':
									select = document.createElement('input');
									select.type = "text";
									select.id = 'l3playerprofileScene';
									select.value = '/Default/ACC/LtPlayerProfile';
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
									break;
							}
						/*select = document.createElement('input');
						select.type = "text";
						select.id = 'l3playerprofileScene';
						select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_PlayerProfile.sum';
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;*/
						break;
						}
						break;
					}
				break;
				
			case 'BUG_DB-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select = document.createElement('select');
						select.style = 'width:130px';
						select.id = 'selectBugdb';
						select.name = select.id;
						
						dataToProcess.forEach(function(bug,index,arr1){
							option = document.createElement('option');
							option.value = bug.bugId;
							option.text = bug.prompt;
							select.appendChild(option);
						});
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						switch(whatToProcess){
							case 'BUG_DB-OPTIONS':
							switch ($('#selected_broadcaster').val().toUpperCase()) {
								case 'DOAD_IN_HOUSE_EVEREST': 
									select = document.createElement('input');
									select.type = "text";
									select.id = 'bugdbScene';
									select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Bug_SingleLine.sum';
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
							
									break;
								case 'DOAD_IN_HOUSE_VIZ':
									select.setAttribute('onchange',"processUserSelection(this)");
								
									select = document.createElement('input');
									select.type = "text";
									select.id = 'bugdbScene';
									select.name = select.id;
									//select.value = '/Default/ACC/LtTimeSince';
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
							
									break;
							}
						break;
						}
						break;
					}
					break;
				}
			
			option = document.createElement('input');
		    option.type = 'button';
			switch (whatToProcess) {
			
			case 'LT-TIEID-DOUBLE-OPTIONS':
				option.name = 'populate_lt_tieId_double_btn';
			    option.value = 'Populate Match ID Double';
			    break;
			case'PREVIOUS_SUMMARY-OPTIONS':
			    option.name = 'populate_previous_summary_btn';
			    option.value = 'Populate Previous Summary';
				break;
			case'NAMESUPER-OPTIONS':
			    option.name = 'populate_namesuper_btn';
			    option.value = 'Populate Namesuper';
				break;
			case 'NAMESUPER_PLAYER-OPTIONS':	
				option.name = 'populate_namesuper_player_btn';
			    option.value = 'Populate Namesuper-Player';
				break;
			
			case'PLAYERPROFILE-OPTIONS':
			    option.name = 'populate_playerprofile_btn';
			    option.value = 'Populate Playerprofile';
				break;
			case'L3PLAYERPROFILE-OPTIONS':
			    option.name = 'populate_l3playerprofile_btn';
			    option.value = 'Populate L3Playerprofile';
				break;
			case 'BUG_DB-OPTIONS':
				option.name = 'populate_bug_db_btn';
			    option.value = 'Populate Bug';
				break;
			}
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
		
	case'INFOBAR-RIGHT-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			switch(whatToProcess){
			case'INFOBAR-RIGHT-OPTIONS': 
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_VIZ':
						dataToProcess.inning.forEach(function(inn,index,arr){
							if(inn.isCurrentInning == 'YES'){
								
								if(inn.inningNumber == 1){
									select = document.createElement('select');
										select.id = 'selectRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'this_over';
										option.text = 'This Over';
										select.appendChild(option);
										
										/*option = document.createElement('option');
										option.value = 'timeline';
										option.text = 'Timeline';
										select.appendChild(option);*/

										select.setAttribute('onclick','processUserSelection(this);');
										
										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
									}
									else{
										select = document.createElement('select');
										select.id = 'selectRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'this_over';
										option.text = 'This Over';
										select.appendChild(option);
										
										/*option = document.createElement('option');
										option.value = 'timeline';
										option.text = 'Timeline';
										select.appendChild(option);*/
										
										select.setAttribute('onclick','processUserSelection(this);');
										
										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
									}
								}
						});
						break;
				}
				break;		
			}

			option = document.createElement('input');
		    option.type = 'button';
		    
			switch (whatToProcess) {
			case'INFOBAR-RIGHT-OPTIONS':
			    option.name = 'populate_infobar_right_btn';
			    option.value = 'Change on Infobar';
				
			    option.id = option.name;
			    option.setAttribute('onclick',"processUserSelection(this)");
			    
			    div = document.createElement('div');
			    div.append(option);
				
				option = document.createElement('input');
				option.type = 'button';
				option.name = 'animate_out_graphic_btn';
				option.id = option.name;
				option.value = 'Animate out ';
				option.setAttribute('onclick','processUserSelection(this)');
		
			    div.append(option);
			    
			    row.insertCell(cellCount).appendChild(div);
			    cellCount = cellCount + 1;
				
				option = document.createElement('input');
				option.type = 'button';
				option.name = 'cancel_graphics_btn';
				option.id = option.name;
				option.value = 'Cancel';
				option.setAttribute('onclick','processUserSelection(this)');
		
			    div.append(option);
			    
			    row.insertCell(cellCount).appendChild(div);
			    cellCount = cellCount + 1;
			    
				document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
	}
		break;

	case'INFOBAR-TOP-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			switch(whatToProcess){
			case'INFOBAR-TOP-OPTIONS':
				dataToProcess.inning.forEach(function(inn,index,arr){
					if(inn.isCurrentInning == 'YES'){
						if(inn.inningNumber == 1){
							select = document.createElement('select');
							select.id = 'selectTopStat';
							select.name = select.id;
							
							option = document.createElement('option');
							option.value = 'vs_bowling_team';
							option.text = 'Vs Bowling Team';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'toss';
							option.text = 'Toss';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'crr';
							option.text = 'CRR';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'boundaries';
							option.text = 'Boundaries';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'last_wicket';
							option.text = 'Last_Wicket';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'partnership';
							option.text = 'Partnership';
							select.appendChild(option);
							
							row.insertCell(cellCount).appendChild(select);
							cellCount = cellCount + 1;
						}
						else{
							select = document.createElement('select');
							select.id = 'selectTopStat';
							select.name = select.id;
							
							option = document.createElement('option');
							option.value = 'equation';
							option.text = 'Equation';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'first_inning_score';
							option.text = 'First Inning Score';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'crr_rrr';
							option.text = 'Current And Required Run Rate';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'boundaries';
							option.text = 'Boundaries';
							select.appendChild(option);
							
							row.insertCell(cellCount).appendChild(select);
							cellCount = cellCount + 1;
							
						}
					}
				});
				
				break;		
				}

			option = document.createElement('input');
		    option.type = 'button';
		    
			switch (whatToProcess) {
			case'INFOBAR-TOP-OPTIONS':
			    option.name = 'populate_infobar_top_btn';
			    option.value = 'Change on Infobar';
				break;
			}
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
	
	case'INFOBAR-BOTTOMLEFT-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			switch(whatToProcess){
			case'INFOBAR-BOTTOMLEFT-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST':
						dataToProcess.inning.forEach(function(inn,index,arr){
							if(inn.isCurrentInning == 'YES'){
								if(inn.inningNumber == 1){
									select = document.createElement('select');
									select.id = 'selectBottomLeftStat';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'current_run_rate';
									option.text = 'Current Run Rate';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'vs_bowling_team';
									option.text = 'vs Bowling team';
									select.appendChild(option);
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
								}
								else{
									select = document.createElement('select');
									select.id = 'selectBottomLeftStat';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'current_run_rate';
									option.text = 'Current Run Rate';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'vs_bowling_team';
									option.text = 'vs Bowling team';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'required_run_rate';
									option.text = 'Required Run Rate';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'target';
									option.text = 'Target';
									select.appendChild(option);
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
									
								}
							}
						});
						break;
						
					case 'DOAD_IN_HOUSE_VIZ':
						dataToProcess.inning.forEach(function(inn,index,arr){
							if(inn.isCurrentInning == 'YES'){
								if(inn.inningNumber == 1){
									select = document.createElement('select');
									select.id = 'selectBottomLeftStat';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'batsman';
									option.text = 'Batsman';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'current_run_rate';
									option.text = 'Current Run Rate';
									select.appendChild(option);
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
								}
								else{
									select = document.createElement('select');
									select.id = 'selectBottomLeftStat';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'batsman';
									option.text = 'Batsman';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'current_run_rate';
									option.text = 'Current Run Rate';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'required_run_rate';
									option.text = 'Required Run Rate';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'equation';
									option.text = 'Equation';
									select.appendChild(option);
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
									
								}
							}
						});
						break;
				}
				break;		
				}

			option = document.createElement('input');
		    option.type = 'button';
		    
			switch (whatToProcess) {
			case'INFOBAR-BOTTOMLEFT-OPTIONS':
			    option.name = 'populate_infobar_bottom-left_btn';
			    option.value = 'Change on Infobar';
				break;
			}
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
	case 'IDENT-OPTIONS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('input');
			select.type = "text";
			select.id = 'infobarScene';
			select.value = '/Default/ACC/ScoreBug';
			
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			case'IDENT-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {	
					case 'DOAD_IN_HOUSE_VIZ':
						dataToProcess.inning.forEach(function(inn,index,arr){
							if(inn.isCurrentInning == 'YES'){
								if(inn.inningNumber == 1){
									
									select = document.createElement('select');
									select.id = 'selectIdent';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'toss';
									option.text = 'Toss';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'venue';
									option.text = 'Venue';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'tournament';
									option.text = 'Tournament';
									select.appendChild(option);
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
								}
								else{
									select = document.createElement('select');
									select.id = 'selectIdent';
									select.name = select.id;

									option = document.createElement('option');
									option.value = 'result';
									option.text = 'Result';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'venue';
									option.text = 'Venue';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'tournament';
									option.text = 'Tournament';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'target';
									option.text = 'Target';
									select.appendChild(option);
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
									
								}
							}
						});
						break;
				}
				break;		
				}

			option = document.createElement('input');
		    option.type = 'button';
		    
			switch (whatToProcess) {
			case'IDENT-OPTIONS':
			    option.name = 'populate_ident_btn';
			    option.value = 'Populate Ident';
				break;
			}
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
	case'INFOBAR-BOTTOMRIGHT-OPTIONS': //case 'INFOBAR-PROMPT-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			switch(whatToProcess){
			case'INFOBAR-BOTTOMRIGHT-OPTIONS': 
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST':
						dataToProcess.inning.forEach(function(inn,index,arr){
							if(inn.isCurrentInning == 'YES'){
								
								if(inn.inningNumber == 1){
									if(inn.fallsOfWickets.length > 0){ 
										select = document.createElement('select');
										select.id = 'selectBottomRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'toss_winning';
										option.text = 'Toss Winning';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'last_wicket';
										option.text = 'Last Wicket';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'super_over';
										option.text = 'Super Over';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'statistics';
										option.text = 'Statistics';
										select.appendChild(option);
										
										select.setAttribute('onclick','processUserSelection(this);');
										
										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
									}
									else{
										select = document.createElement('select');
										select.id = 'selectBottomRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'toss_winning';
										option.text = 'Toss Winning';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'super_over';
										option.text = 'Super Over';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'statistics';
										option.text = 'Statistics';
										select.appendChild(option);
										
										select.setAttribute('onclick','processUserSelection(this);');

										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
									}
								}
								else{
									if(inn.fallsOfWickets.length > 0){
										select = document.createElement('select');
										select.id = 'selectBottomRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'toss_winning';
										option.text = 'Toss Winning';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'super_over';
										option.text = 'Super Over';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'equation';
										option.text = 'Equation';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'last_wicket';
										option.text = 'Last Wicket';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'comparision';
										option.text = 'Comparision';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'statistics';
										option.text = 'Statistics';
										select.appendChild(option);
										
										select.setAttribute('onclick','processUserSelection(this);');
										
										
										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
									}
									else{
										select = document.createElement('select');
										select.id = 'selectBottomRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'toss_winning';
										option.text = 'Toss Winning';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'super_over';
										option.text = 'Super Over';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'equation';
										option.text = 'Equation';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'comparision';
										option.text = 'Comparision';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'statistics';
										option.text = 'Statistics';
										select.appendChild(option);
										
										select.setAttribute('onclick','processUserSelection(this);');
										
										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
									}
									
								}
							}
						});
						break;
					case 'DOAD_IN_HOUSE_VIZ':
						dataToProcess.inning.forEach(function(inn,index,arr){
							if(inn.isCurrentInning == 'YES'){
								
								if(inn.inningNumber == 1){
									if(inn.fallsOfWickets.length > 0){
										select = document.createElement('select');
										select.id = 'selectBottomRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'bowler';
										option.text = 'Bowler';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'projected';
										option.text = 'Projected';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'partnership';
										option.text = 'Partnership';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'last_wicket';
										option.text = 'Last Wicket';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'bowling_end';
										option.text = 'Bowling End';
										select.appendChild(option);
										
										
										
										select.setAttribute('onclick','processUserSelection(this);');
										
										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
									}else{
										select = document.createElement('select');
										select.id = 'selectBottomRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'bowler';
										option.text = 'Bowler';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'projected';
										option.text = 'Projected';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'partnership';
										option.text = 'Partnership';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'bowling_end';
										option.text = 'Bowling End';
										select.appendChild(option);
										
										
										
										select.setAttribute('onclick','processUserSelection(this);');
										
										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
									}
										
									}else{
										if(inn.fallsOfWickets.length > 0){
											select = document.createElement('select');
											select.id = 'selectBottomRightStat';
											select.name = select.id;
											
											option = document.createElement('option');
											option.value = 'bowler';
											option.text = 'Bowler';
											select.appendChild(option);
											
											option = document.createElement('option');
											option.value = 'target';
											option.text = 'Target';
											select.appendChild(option);
											
											option = document.createElement('option');
											option.value = 'partnership';
											option.text = 'Partnership';
											select.appendChild(option);
											
											option = document.createElement('option');
											option.value = 'last_wicket';
											option.text = 'Last Wicket';
											select.appendChild(option);
											
											option = document.createElement('option');
											option.value = 'bowling_end';
											option.text = 'Bowling End';
											select.appendChild(option);
											
											
											/*option = document.createElement('option');
											option.value = 'dot_ball';
											option.text = 'Dot Ball';
											select.appendChild(option);
											
											option = document.createElement('option');
											option.value = 'statistics';
											option.text = 'Statistics';
											select.appendChild(option);*/
											
											select.setAttribute('onclick','processUserSelection(this);');
											
											row.insertCell(cellCount).appendChild(select);
											cellCount = cellCount + 1;
										}else{
											select = document.createElement('select');
										select.id = 'selectBottomRightStat';
										select.name = select.id;
										
										option = document.createElement('option');
										option.value = 'bowler';
										option.text = 'Bowler';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'target';
										option.text = 'Target';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'partnership';
										option.text = 'Partnership';
										select.appendChild(option);
										
										option = document.createElement('option');
										option.value = 'bowling_end';
										option.text = 'Bowling End';
										select.appendChild(option);
										
										
										/*option = document.createElement('option');
										option.value = 'dot_ball';
										option.text = 'Dot Ball';
										select.appendChild(option);
										
										*/
										
										select.setAttribute('onclick','processUserSelection(this);');
										
										row.insertCell(cellCount).appendChild(select);
										cellCount = cellCount + 1;
										}
										
									}
								}
						});
						break;
				}
				break;
				case 'INFOBAR-PROMPT-OPTIONS':
				
				select = document.createElement('select');
				select.id = 'selectPrompt';
				select.name = select.id;
				
				dataToProcess.forEach(function(pro,index,arr1){
					option = document.createElement('option');
					option.value = pro.order;
					option.text = pro.order + '-' + pro.prompt ;
					select.appendChild(option);
				});
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
					
				break;	
					
				}

			option = document.createElement('input');
		    option.type = 'button';
		    
			switch (whatToProcess) {
			case'INFOBAR-BOTTOMRIGHT-OPTIONS':
			    option.name = 'populate_infobar_bottom-right_btn';
			    option.value = 'Change on Infobar';
				break;
			
			}
			switch (whatToProcess) {
				case 'INFOBAR-PROMPT-OPTIONS':
				option.name = 'populate_infobar_prompt_btn';
			    option.value = 'Change on Infobar';
				
				option.id = option.name;
			    option.setAttribute('onclick',"processUserSelection(this)");
			    
			    div = document.createElement('div');
			    div.append(option);			
				break;
			}
			
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
	case'INFOBAR-BOTTOM-OPTIONS': case 'INFOBAR-PROMPT-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			switch(whatToProcess){
			case'INFOBAR-BOTTOM-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
				case 'DOAD_IN_HOUSE_EVEREST':
					dataToProcess.inning.forEach(function(inn,index,arr){
						if(inn.isCurrentInning == 'YES'){
							if(inn.inningNumber == 1){
								select = document.createElement('select');
								select.id = 'selectBottomStat';
								select.name = select.id;
								
								option = document.createElement('option');
								option.value = 'boundaries';
								option.text = 'Boundaries';
								select.appendChild(option);
								
								option = document.createElement('option');
								option.value = 'partnership';
								option.text = 'Partnership';
								select.appendChild(option);
								
								option = document.createElement('option');
								option.value = 'projected_score';
								option.text = 'Projected_Score';
								select.appendChild(option);
								
								select.setAttribute('onclick','processUserSelection(this);');
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
							}
							else{
								select = document.createElement('select');
								select.id = 'selectBottomStat';
								select.name = select.id;
								
								option = document.createElement('option');
								option.value = 'boundaries';
								option.text = 'Boundaries';
								select.appendChild(option);
								
								option = document.createElement('option');
								option.value = 'partnership';
								option.text = 'Partnership';
								select.appendChild(option);
								
								select.setAttribute('onclick','processUserSelection(this);');
								
								row.insertCell(cellCount).appendChild(select);
								cellCount = cellCount + 1;
								
							}
						}
					});
					break;
				case 'DOAD_IN_HOUSE_VIZ':
					dataToProcess.inning.forEach(function(inn,index,arr){
						if(inn.isCurrentInning == 'YES'){
							if(inn.inningNumber == 1){
								if(inn.fallsOfWickets.length > 0){
									select = document.createElement('select');
									select.id = 'selectBottomStat';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'inning_dot_counter';
									option.text = 'Inning Dot Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_fours_counter';
									option.text = 'Inning Fours Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_six_counter';
									option.text = 'Inning Six Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'boundaries';
									option.text = 'Boundaries';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'partnership';
									option.text = 'Partnership';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'projected_score';
									option.text = 'Projected_Score';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'last_wicket';
									option.text = 'Last Wicket';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'timeline';
									option.text = 'TimeLine';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'statistics';
									option.text = 'Statistics';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'ball_since';
									option.text = 'Ball Since Last Boundary';
									select.appendChild(option);
									
									select.setAttribute('onclick','processUserSelection(this);');
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1; 
								}else{
									select = document.createElement('select');
									select.id = 'selectBottomStat';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'inning_dot_counter';
									option.text = 'Inning Dot Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_fours_counter';
									option.text = 'Inning Fours Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_six_counter';
									option.text = 'Inning Six Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'boundaries';
									option.text = 'Boundaries';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'partnership';
									option.text = 'Partnership';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'projected_score';
									option.text = 'Projected_Score';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'timeline';
									option.text = 'TimeLine';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'ball_since';
									option.text = 'Ball Since Last Boundary';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'statistics';
									option.text = 'Statistics';
									select.appendChild(option);
									
									select.setAttribute('onclick','processUserSelection(this);');
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
								}
								
							}
							else{
								if(inn.fallsOfWickets.length > 0){
									select = document.createElement('select');
									select.id = 'selectBottomStat';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'to_win';
									option.text = 'To Win';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'equation';
									option.text = 'Equation';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_dot_counter';
									option.text = 'Inning Dot Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_fours_counter';
									option.text = 'Inning Fours Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_six_counter';
									option.text = 'Inning Six Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'comparision';
									option.text = 'Comparision';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'boundaries';
									option.text = 'Boundaries';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'partnership';
									option.text = 'Partnership';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'last_wicket';
									option.text = 'Last Wicket';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'timeline';
									option.text = 'TimeLine';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'ball_since';
									option.text = 'Ball Since Last Boundary';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'statistics';
									option.text = 'Statistics';
									select.appendChild(option);
									
									select.setAttribute('onclick','processUserSelection(this);');
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
								}else{
									select = document.createElement('select');
									select.id = 'selectBottomStat';
									select.name = select.id;
									
									option = document.createElement('option');
									option.value = 'to_win';
									option.text = 'To Win';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'equation';
									option.text = 'Equation';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_dot_counter';
									option.text = 'Inning Dot Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_fours_counter';
									option.text = 'Inning Fours Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'inning_six_counter';
									option.text = 'Inning Six Counter';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'comparision';
									option.text = 'Comparision';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'boundaries';
									option.text = 'Boundaries';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'partnership';
									option.text = 'Partnership';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'timeline';
									option.text = 'TimeLine';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'ball_since';
									option.text = 'Ball Since Last Boundary';
									select.appendChild(option);
									
									option = document.createElement('option');
									option.value = 'statistics';
									option.text = 'Statistics';
									select.appendChild(option);
									
									select.setAttribute('onclick','processUserSelection(this);');
									
									row.insertCell(cellCount).appendChild(select);
									cellCount = cellCount + 1;
								}
							}
						}
					});
					break;
				}
				break;	
				case 'INFOBAR-PROMPT-OPTIONS':
				
				select = document.createElement('select');
				select.id = 'selectPrompt';
				select.name = select.id;
				
				dataToProcess.forEach(function(pro,index,arr1){
					option = document.createElement('option');
					option.value = pro.order;
					option.text = pro.order + '-' + pro.prompt ;
					select.appendChild(option);
				});
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
					
				break;	
				}

			option = document.createElement('input');
		    option.type = 'button';
		    
			switch (whatToProcess) {
			case'INFOBAR-BOTTOM-OPTIONS':
			    option.name = 'populate_infobar_bottom_btn';
			    option.value = 'Change on Infobar';
				
				option.id = option.name;
			    option.setAttribute('onclick',"processUserSelection(this)");
			    
			    div = document.createElement('div');
			    div.append(option);
			    
			    option = document.createElement('input');
				option.type = 'button';
				option.name = 'animate_out_bottom_btn';
				option.id = option.name;
				option.value = 'Animate out ';
				option.setAttribute('onclick','processUserSelection(this)');
		
			    div.append(option);
			    
			    row.insertCell(cellCount).appendChild(div);
			    cellCount = cellCount + 1;
				break;
			
			}
			switch (whatToProcess) {
				case 'INFOBAR-PROMPT-OPTIONS':
				option.name = 'populate_infobar_prompt_btn';
			    option.value = 'Change on Infobar';
				
				option.id = option.name;
			    option.setAttribute('onclick',"processUserSelection(this)");
			    
			    div = document.createElement('div');
			    div.append(option);			
				break;
			}
			//switch (whatToProcess) {
			
			//}
		    
		    option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
	case 'INFOBAR-OPTIONS':
		//alert("Broadcaster = " +$('#selected_broadcaster').val());
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			
			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('input');
			select.type = "text";
			select.id = 'infobarScene';
			select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Scorebug.sum';
			
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			select = document.createElement('select');
			select.id = 'selectTopLeftStats';
			select.name = select.id;
			
			
			option = document.createElement('option');
			option.value = 'batsman';
			option.text = 'Batsman';
			select.appendChild(option);
			
			
			row.insertCell(cellCount).appendChild(select);
			
			cellCount = cellCount + 1;
			
			select = document.createElement('select');
			select.id = 'selectTopRightStats';
			select.name = select.id;
			
			option = document.createElement('option');
			option.value = 'bowler';
			option.text = 'Bowler';
			select.appendChild(option);
			
			option = document.createElement('option');
			option.value = 'this_over';
			option.text = 'This Over';
			select.appendChild(option);
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			dataToProcess.inning.forEach(function(inn,index,arr){
					if(inn.isCurrentInning == 'YES'){
						if(inn.inningNumber == 1){
							select = document.createElement('select');
							select.id = 'selectBottomLeftStats';
							select.name = select.id;
							
							option = document.createElement('option');
							option.value = 'vs_bowling_team';
							option.text = 'vs Bowling Team';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'current_run_rate';
							option.text = 'Current Run Rate';
							select.appendChild(option);
							
							row.insertCell(cellCount).appendChild(select);
							cellCount = cellCount + 1;
							
							select = document.createElement('select');
							select.id = 'selectBottomRightStats';
							select.name = select.id;
							
							option = document.createElement('option');
							option.value = 'toss_winning';
							option.text = 'Toss Winning';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'tournament_name';
							option.text = 'Tournament Name';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'venue_name';
							option.text = 'Venue Name';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'super_over';
							option.text = 'Super Over';
							select.appendChild(option);
							
							row.insertCell(cellCount).appendChild(select);
							cellCount = cellCount + 1;
						
					}
					else{
						select = document.createElement('select');
						select.id = 'selectBottomLeftStats';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'target';
						option.text = 'Target';
						select.appendChild(option);	
						
						option = document.createElement('option');
						option.value = 'required_run_rate';
						option.text = 'Required Run Rate';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'current_run_rate';
						option.text = 'Current Run Rate';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'vs_bowling_team';
						option.text = 'vs Bowling Team';
						select.appendChild(option);
									
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectBottomRightStats';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'equation';
						option.text = 'Equation';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'tournament_name';
						option.text = 'Tournament Name';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'venue_name';
						option.text = 'Venue Name';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'super_over';
						option.text = 'Super Over';
						select.appendChild(option);
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
					}
					}
				});
				
			option = document.createElement('input');
		    option.type = 'button';
		    option.name = 'populate_infobar_btn';
			option.value = 'Populate Infobar';
			
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
			
		case 'DOAD_IN_HOUSE_VIZ':
			
			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('input');
			select.type = "text";
			select.id = 'infobarScene';
			select.value = '/Default/ACC/ScoreBug';
			
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			select = document.createElement('select');
			select.id = 'selectTopLeftStats';
			select.name = select.id;
			
			
			option = document.createElement('option');
			option.value = 'batsman';
			option.text = 'Batsman';
			select.appendChild(option);
			
			
			row.insertCell(cellCount).appendChild(select);
			
			cellCount = cellCount + 1;
			
			select = document.createElement('select');
			select.id = 'selectSection4';
			select.name = select.id;
			
			option = document.createElement('option');
			option.value = 'bowler';
			option.text = 'Bowler';
			select.appendChild(option);
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			/*select = document.createElement('select');
			select.id = 'selectSection5';
			select.name = select.id;
			
			option = document.createElement('option');
			option.value = 'This_Over';
			option.text = 'This Over';
			select.appendChild(option);
			
			option = document.createElement('option');
			option.value = 'economy';
			option.text = 'Economy';
			select.appendChild(option);
			
			option = document.createElement('option');
			option.value = 'bowling_end';
			option.text = 'Bowling End';
			select.appendChild(option);
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;*/
			
			option = document.createElement('input');
		    option.type = 'button';
		    option.name = 'populate_infobar_btn';
			option.value = 'Populate Infobar';
			
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
	
	case 'GENERIC-OPTIONS':
		//alert("Broadcaster = " +$('#selected_broadcaster').val());
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST':
			
			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('input');
			select.type = "text";
			select.id = 'genericScene';
			select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_TeamDetails.sum';
			
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			dataToProcess.inning.forEach(function(inn,index,arr){
					if(inn.isCurrentInning == 'YES'){
						if(inn.inningNumber == 1){
							select = document.createElement('select');
							select.id = 'selectStats';
							select.name = select.id;
							
							option = document.createElement('option');
							option.value = 'boundaries';
							option.text = 'Boundaries';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'current_run_rate';
							option.text = 'Current Run Rate';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'partnership';
							option.text = 'Partnership';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'last_wicket';
							option.text = 'Last Wicket';
							select.appendChild(option);
							
							row.insertCell(cellCount).appendChild(select);
							cellCount = cellCount + 1;
						
					}
					else{
						select = document.createElement('select');
							select.id = 'selectStats';
							select.name = select.id;
							
							option = document.createElement('option');
							option.value = 'boundaries';
							option.text = 'Boundaries';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'current_run_rate';
							option.text = 'Current Run Rate';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'runs_balls';
							option.text = 'Runs and Balls';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'partnership';
							option.text = 'Partnership';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'required_run_rate';
							option.text = 'Required Run Rate';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'last_wicket';
							option.text = 'Last Wicket';
							select.appendChild(option);
							
							option = document.createElement('option');
							option.value = 'comparision';
							option.text = 'Comparision';
							select.appendChild(option);
							
							row.insertCell(cellCount).appendChild(select);
							cellCount = cellCount + 1;
					}
					}
				});
				
			option = document.createElement('input');
		    option.type = 'button';
		    option.name = 'populate_generic_btn';
			option.value = 'Populate Generic';
			
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
		
	case'PLAYINGXI-OPTIONS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectPlayingXI';
			select.name = select.id;
			
			
			option = document.createElement('option');
			option.value = dataToProcess.homeTeamId;
			option.text = dataToProcess.homeTeam.shortname;
			select.appendChild(option);
			
			option = document.createElement('option');
			option.value = dataToProcess.awayTeamId;
			option.text = dataToProcess.awayTeam.shortname;
			select.appendChild(option);
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_EVEREST': 
				select = document.createElement('input');
				select.type = "text";
				select.id = 'playingxiScene';
				select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Playing_XI_Image.sum';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				break;
			case 'DOAD_IN_HOUSE_VIZ':
				select = document.createElement('input');
				select.type = "text";
				select.id = 'playingxiScene';
				select.value = '/Default/ACC/TeamLineUp_Image';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				break;
			}
			
			option = document.createElement('input');
		    option.type = 'button';
		    option.name = 'populate_playingxi_btn';
		    option.value = 'Populate PlayingXI';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			break;
		}
		break;
		
	case'SQUAD-OPTIONS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectSquad';
			select.name = select.id;
			
			
			option = document.createElement('option');
			option.value = dataToProcess.homeTeamId;
			option.text = dataToProcess.homeTeam.shortname;
			select.appendChild(option);
			
			option = document.createElement('option');
			option.value = dataToProcess.awayTeamId;
			option.text = dataToProcess.awayTeam.shortname;
			select.appendChild(option);
			
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_EVEREST': 
				select = document.createElement('input');
				select.type = "text";
				select.id = 'playingxiScene';
				select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/Playing_XI_Image.sum';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				break;
			case 'DOAD_IN_HOUSE_VIZ':
				select = document.createElement('input');
				select.type = "text";
				select.id = 'squadScene';
				select.value = '/Default/ACC/Squad';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				break;
			}
			
			option = document.createElement('input');
		    option.type = 'button';
		    option.name = 'populate_squad_btn';
		    option.value = 'Populate Squad';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			break;
		}
		break;
		
	case'PLAYERSUMMARY-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectedInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			
			
			case'PLAYERSUMMARY-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_EVEREST': 
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectPlayerData';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'playersummaryScene';
				select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_BattingSummary.sum';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				break;
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectPlayerData';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'playersummaryScene';
				select.value = '/Default/ACC/Lt_BatingSummary';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
			}
			option = document.createElement('input');
	    	option.type = 'button';
	    	
	    	option.name = 'populate_playersummary_btn';
		    option.value = 'Populate Player Summary';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			
		}
			break;
	}
		break;
	
	case'BATSMAN_THIS_MATCH-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectPositionLandmarkInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			
			
			case'BATSMAN_THIS_MATCH-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectpositionlandmark';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'batsmanthismatchScene';
				select.value = '/Default/ACC/Lt_BatingSummary';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
			}
			option = document.createElement('input');
	    	option.type = 'button';
	    	
	    	option.name = 'populate_batsman_this_match_btn';
		    option.value = 'Populate Batsman';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			
		}
			break;
	}
		break;
		
	case'BOWLER_THIS_MATCH-OPTIONS': 
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectbowlerthismatchInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			
			
			case'BOWLER_THIS_MATCH-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectbowlerthismatch';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'bowlerthismatchScene';
				select.value = '/Default/ACC/Lt_BowlerBowlingDetails';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
			}
			option = document.createElement('input');
	    	option.type = 'button';
	    	
	    	option.name = 'populate_bowler_this_match_btn';
		    option.value = 'Populate Bowler';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			
		}
			break;
	}
		break;
		
	case'BOWLERSTYLE-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectBowlerInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			
			
			case'BOWLERSTYLE-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_EVEREST':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectbowler';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'bowlerstyleScene';
				select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_NameSuper.sum';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
				
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectbowler';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'bowlerstyleScene';
				select.value = '/Default/ACC/LtTimeSince';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
			}
			option = document.createElement('input');
	    	option.type = 'button';
	    	
	    	option.name = 'populate_bowlerstyle_btn';
		    option.value = 'Populate Bowler Style';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			
		}
			break;
	}
		break;
		
	case'BATSMANSTYLE-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectPositionLandmarkInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			
			case'BATSMANSTYLE-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_EVEREST':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectpositionlandmark';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'batsmanstyleScene';
				select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_NameSuper.sum';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				break;
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectpositionlandmark';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'batsmanstyleScene';
				select.value = '/Default/ACC/LtTimeSince';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
			}
			option = document.createElement('input');
	    	option.type = 'button';
	    	
	    	option.name = 'populate_batsmanstyle_btn';
		    option.value = 'Populate Batsman';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			
		}
			break;
	}
		break;		
		
	case'BOWLERDETAILS-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectedInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			
			
			case'BOWLERDETAILS-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectPlayerData';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'playersummaryScene';
				select.value = '/Default/ACC/Lt_BowlerBowlingDetails';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
			}
			option = document.createElement('input');
	    	option.type = 'button';
	    	
	    	option.name = 'populate_bowlerdetails_btn';
		    option.value = 'Populate Bowler Summary';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			
		}
			break;
	}
		break;
		
	case 'BOWLERSUMMARY-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectedInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
			
			
			case 'BOWLERSUMMARY-OPTIONS':
			switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_VIZ':
				select.setAttribute('onchange',"processUserSelection(this)");
		
				select = document.createElement('select');
				select.id = 'selectPlayerData';
				select.name = select.id;
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				select = document.createElement('input');
				select.type = "text";
				select.id = 'bowlersummaryScene';
				select.value = '/Default/ACC/Lt_BatingSummary';
				
				row.insertCell(cellCount).appendChild(select);
				cellCount = cellCount + 1;
				
				break;
			}
			option = document.createElement('input');
	    	option.type = 'button';
	    	
	    	option.name = 'populate_bowlersummary_btn';
		    option.value = 'Populate Bowler Summary';
		    
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';
			
		}
			break;
	}
		break;
		
	case 'COMPARISION-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
		    
		    switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_EVEREST':
				 switch(whatToProcess){
					case 'COMPARISION-OPTIONS':
						select = document.createElement('input');
						select.type = "text";
						select.id = 'comparisionScene';
						select.value = 'D:/DOAD_In_House_Everest/Everest_Cricket/EVEREST_APL2022/Scenes/LT_Comparison.sum';
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
					break;
					}
				break;
				
			case 'DOAD_IN_HOUSE_VIZ':
				switch(whatToProcess){
					case 'COMPARISION-OPTIONS':
					select = document.createElement('input');
					select.type = "text";
					select.id = 'comparisionScene';
					select.value = '/Default/ACC/LtComparison';
					
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
					break;
				}
				break;
					
				}
			option = document.createElement('input');
		    option.type = 'button';
		   	option.name = 'populate_comparision_btn';
		    option.value = 'Populate Comparision';
				
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
	
	case 'NEXTTOBAT-OPTIONS':
	
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
		    
		    switch ($('#selected_broadcaster').val().toUpperCase()) {
			case 'DOAD_IN_HOUSE_VIZ':
				switch(whatToProcess){
					case 'NEXTTOBAT-OPTIONS':
					select = document.createElement('input');
					select.type = "text";
					select.id = 'nexttobatScene';
					select.value = '/Default/ACC/LtNextToBat';
					select.style = 'width:130px'
					
					row.insertCell(cellCount).appendChild(select);
					cellCount = cellCount + 1;
					break;
				}
				break;
					
				}
			option = document.createElement('input');
		    option.type = 'button';
		   	option.name = 'populate_next_to_bat_btn';
		    option.value = 'Populate Next To Bat';
				
		    option.id = option.name;
		    option.setAttribute('onclick',"processUserSelection(this)");
		    
		    div = document.createElement('div');
		    div.append(option);

			option = document.createElement('input');
			option.type = 'button';
			option.name = 'cancel_graphics_btn';
			option.id = option.name;
			option.value = 'Cancel';
			option.setAttribute('onclick','processUserSelection(this)');
	
		    div.append(option);
		    
		    row.insertCell(cellCount).appendChild(div);
		    cellCount = cellCount + 1;
		    
			document.getElementById('select_graphic_options_div').style.display = '';

			break;
		}
		break;
		
	case 'LANDMARK-OPTIONS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectLandmarkInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
				
			case 'LANDMARK-OPTIONS': 
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select.setAttribute('onchange',"processUserSelection(this)");
						//alert('hi');
						select = document.createElement('select');
						select.id = 'selectedStatsType';
						select.name = select.id;
						
						option = document.createElement('option');
						option.value = 'Batsman';
						option.text = 'Batsman';
						select.appendChild(option);
						
						option = document.createElement('option');
						option.value = 'Bowler';
						option.text = 'Bowler';
						select.appendChild(option);
						
					    select.setAttribute('onchange',"processUserSelection(this)");
						row.insertCell(cellCount).appendChild(select);
						
						cellCount = cellCount + 1;
						
						select = document.createElement('select');
						select.id = 'selectlandmarkPlayers';
						select.name = select.id;
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('input');
						select.type = "text";
						select.id = 'landmarkScene';
						select.value = '/Default/ACC/Landmark';
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						option = document.createElement('input');
	    				option.type = 'button';
	    				
	    				option.name = 'populate_landmark_btn';
			    		option.value = 'Populate LandMark';
			    		
			    		option.id = option.name;
					    option.setAttribute('onclick',"processUserSelection(this)");
					    
					    div = document.createElement('div');
					    div.append(option);
			
						option = document.createElement('input');
						option.type = 'button';
						option.name = 'cancel_graphics_btn';
						option.id = option.name;
						option.value = 'Cancel';
						option.setAttribute('onclick','processUserSelection(this)');
				
					    div.append(option);
					    
					    row.insertCell(cellCount).appendChild(div);
					    cellCount = cellCount + 1;
					    
						document.getElementById('select_graphic_options_div').style.display = '';
						break;
					}
				break;
			}
			break;
		}
		break;
		
	case 'POSITION_LANDMARK-OPTIONS':
		switch ($('#selected_broadcaster').val().toUpperCase()) {
		
		case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':

			$('#select_graphic_options_div').empty();
	
			header_text = document.createElement('h6');
			header_text.innerHTML = 'Select Graphic Options';
			document.getElementById('select_graphic_options_div').appendChild(header_text);
			
			table = document.createElement('table');
			table.setAttribute('class', 'table table-bordered');
					
			tbody = document.createElement('tbody');
	
			table.appendChild(tbody);
			document.getElementById('select_graphic_options_div').appendChild(table);
			
			row = tbody.insertRow(tbody.rows.length);
			
			select = document.createElement('select');
			select.id = 'selectPositionLandmarkInning';
			select.name = select.id;
			
			if(document.getElementById('selected_match_max_overs').value > 0) {
				max_cols = 2;
			} else {
				max_cols = 4;
			}
			for(var i=1; i<=max_cols; i++) {
				option = document.createElement('option');
				option.value = i;
			    option.text = 'Inning ' + i;
			    select.appendChild(option);
			}
			row.insertCell(cellCount).appendChild(select);
			cellCount = cellCount + 1;
			
			switch(whatToProcess){
				
			case 'POSITION_LANDMARK-OPTIONS':
				switch ($('#selected_broadcaster').val().toUpperCase()) {
					case 'DOAD_IN_HOUSE_EVEREST': case 'DOAD_IN_HOUSE_VIZ':
						select.setAttribute('onchange',"processUserSelection(this)");
						//alert('hi');
						select = document.createElement('select');
						select.id = 'selectpositionlandmark';
						select.name = select.id;
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						select = document.createElement('input');
						select.type = "text";
						select.id = 'positionlandmarkScene';
						select.value = '/Default/ACC/PlayerLandmarkImage';
						
						row.insertCell(cellCount).appendChild(select);
						cellCount = cellCount + 1;
						
						option = document.createElement('input');
	    				option.type = 'button';
	    				
	    				option.name = 'populate_position_landmark_btn';
			    		option.value = 'Populate LandMark';
			    		
			    		option.id = option.name;
					    option.setAttribute('onclick',"processUserSelection(this)");
					    
					    div = document.createElement('div');
					    div.append(option);
			
						option = document.createElement('input');
						option.type = 'button';
						option.name = 'cancel_graphics_btn';
						option.id = option.name;
						option.value = 'Cancel';
						option.setAttribute('onclick','processUserSelection(this)');
				
					    div.append(option);
					    
					    row.insertCell(cellCount).appendChild(div);
					    cellCount = cellCount + 1;
					    
						document.getElementById('select_graphic_options_div').style.display = '';
						break;
					}
				break;
			}
			break;
		}
		break;
	}
	
	
}
function checkEmpty(inputBox,textToShow) {

	var name = $(inputBox).attr('id');
	
	document.getElementById(name + '-validation').innerHTML = '';
	document.getElementById(name + '-validation').style.display = 'none';
	$(inputBox).css('border','');
	if(document.getElementById(name).value.trim() == '') {
		$(inputBox).css('border','#E11E26 2px solid');
		document.getElementById(name + '-validation').innerHTML = textToShow + ' required';
		document.getElementById(name + '-validation').style.display = '';
		document.getElementById(name).focus({preventScroll:false});
		return false;
	}
	return true;	
}